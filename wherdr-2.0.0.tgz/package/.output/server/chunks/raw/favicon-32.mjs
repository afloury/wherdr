import { b as base64ToUint8Array } from '../virtual/_raw-helpers.mjs';

// ROLLUP_NO_REPLACE 
 const favicon32 = base64ToUint8Array("iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAAaklEQVR42mMQEpWmKWIYtWDUglELYBY8e/UJDZFqEC4TaG8BLuOQxTE1Y8riMoG+FmAqxWU0rsDENI2+FhAfOMQEFL0swDSIGMuICVKc+YAmFhCffUjNkgNtATEZbShYMFrhjFowagFlCADxhBAubjclYgAAAABJRU5ErkJggg==");

export { favicon32 as default };
//# sourceMappingURL=favicon-32.mjs.map

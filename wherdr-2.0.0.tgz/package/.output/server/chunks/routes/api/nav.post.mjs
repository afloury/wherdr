import { a as defineApi, P as PANE_RE, H as HerdrError, f as findPane, h as herdr, e as watchScreen, aU as refreshNativeScreen, aV as TOP, aM as readMenu, aO as menuIdentity, b as screenChoices, aR as clickMovesOnly, g as choicesCache, p as poll } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const KEYS = /* @__PURE__ */ new Set(["up", "down", "enter", "esc", "left", "right"]);
const nav_post = defineApi(async (event, b) => {
  var _a, _b, _c, _d, _e;
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  const pane = b.pane_id;
  if ((_a = findPane(pane)) == null ? void 0 : _a.stopped) throw new HerdrError("stale", "Use the restart buttons for this stopped agent.");
  const key = String(b.key || "");
  if (!KEYS.has(key)) throw new HerdrError("bad_request", "Invalid key");
  try {
    const shown = findPane(pane);
    if ((key === "up" || key === "down") && shown && !shown.leaving && shown.status !== "working" && !((_b = shown.menu) == null ? void 0 : _b.unavailable) && !((_c = shown.prompt) == null ? void 0 : _c.unavailable) && (shown.menu || shown.prompt)) {
      await herdr("pane.send_input", { pane_id: pane, keys: [key] });
      watchScreen(pane, 3e4);
      setTimeout(() => refreshNativeScreen(pane), 50);
      return { ok: true };
    }
    const r = await herdr("pane.read", { pane_id: pane, source: "detection" }, 4e3);
    const text = r.read && r.read.text;
    const agent = (_d = findPane(pane)) == null ? void 0 : _d.agent;
    const framed = agent !== "omp" && String(text || "").split("\n").some((l) => TOP.test(l));
    const menu = framed ? await readMenu(pane) : null;
    if (key === "enter") {
      const current = menu ? menuIdentity(menu) : (_e = screenChoices(text, agent)) == null ? void 0 : _e.identity;
      if (!b.identity || current !== b.identity) throw new HerdrError("stale", "The question has changed \u2014 check the current screen.");
    }
    if (menu) {
      if (key === "enter" && clickMovesOnly(menu)) throw new HerdrError("stale", "Enter doesn\u2019t confirm from here \u2014 use the buttons.");
      if (key === "left" || key === "right") throw new HerdrError("stale", "The screen has changed \u2014 check the current screen.");
    } else {
      const choices = screenChoices(text, agent);
      if (!choices || (key === "left" || key === "right") && !(choices.tabs && !choices.typing)) {
        throw new HerdrError("stale", "The screen has changed \u2014 check the current screen.");
      }
    }
    await herdr("pane.send_input", { pane_id: pane, keys: [key] });
    watchScreen(pane, 3e4);
    setTimeout(() => refreshNativeScreen(pane), 50);
    return { ok: true };
  } finally {
    choicesCache.delete(pane);
    setTimeout(poll, 0);
  }
});

export { nav_post as default };
//# sourceMappingURL=nav.post.mjs.map

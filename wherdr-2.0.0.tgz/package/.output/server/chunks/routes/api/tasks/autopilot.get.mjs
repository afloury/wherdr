import { a as defineApi, i as getQuery, bQ as autopilotStatuses, bR as coordinatorAutopilot } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const autopilot_get = defineApi(async (event) => {
  var _a, _b;
  const q = getQuery(event);
  if (q.kind === void 0) return autopilotStatuses((_a = q.machine) != null ? _a : "");
  return coordinatorAutopilot((_b = q.machine) != null ? _b : "", { kind: q.kind, repo: q.repo });
});

export { autopilot_get as default };
//# sourceMappingURL=autopilot.get.mjs.map

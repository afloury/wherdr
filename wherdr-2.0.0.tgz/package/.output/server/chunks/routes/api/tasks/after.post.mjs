import { a as defineApi, bN as clearTaskAfter } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const after_post = defineApi((_event, b) => {
  var _a;
  return clearTaskAfter((_a = b.machine) != null ? _a : "", b.id);
});

export { after_post as default };
//# sourceMappingURL=after.post.mjs.map

import { a as defineApi, bH as cleanSettingsPatch, H as HerdrError, bI as patchSettings } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const settings_post = defineApi(async (_event, body) => {
  const patch = cleanSettingsPatch(body.settings);
  if (!patch) throw new HerdrError("bad_settings", "Invalid settings");
  return { settings: await patchSettings(patch, { onlyMissing: body.migrate === true }) };
});

export { settings_post as default };
//# sourceMappingURL=settings.post.mjs.map

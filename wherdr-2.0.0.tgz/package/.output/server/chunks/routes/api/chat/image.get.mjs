import { d as defineEventHandler, i as getQuery, f as findPane, y as transcripts, s as sendError, I as sendImage } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const image_get = defineEventHandler(async (event) => {
  const q = getQuery(event);
  try {
    const p = findPane(String(q.pane || ""));
    const img = p ? await transcripts.image(p, String(q.file || ""), String(q.ref || ""), Number(q.i) || 0) : null;
    if (!img) return sendError(event, 404, { error: "Image not found" });
    return sendImage(event, img);
  } catch {
    return sendError(event, 404, { error: "Image not found" });
  }
});

export { image_get as default };
//# sourceMappingURL=image.get.mjs.map

import { a as defineApi, _ as MACHINE_KEY_RE, H as HerdrError, $ as getMachine } from '../../../nitro/nitro.mjs';
import { b as setAwake } from '../../../_/awake.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const MODES = /* @__PURE__ */ new Set(["off", "hour", "fourHours", "evening", "untilOff", "extend"]);
const awake_post = defineApi(async (_event, body) => {
  const key = typeof body.key === "string" ? body.key : null;
  if (key === null || key !== "" && !MACHINE_KEY_RE.test(key)) throw new HerdrError("bad_machine", "unknown machine");
  const machine = getMachine(key);
  if (!machine || machine.status !== "online") throw new HerdrError("bad_machine", "Machine unreachable");
  const mode = typeof body.mode === "string" ? body.mode : "";
  if (!MODES.has(mode) || typeof body.lid !== "boolean") throw new HerdrError("bad_mode", "Invalid keep-awake option");
  return setAwake(machine, mode, body.lid);
});

export { awake_post as default };
//# sourceMappingURL=awake.post.mjs.map

import { a as defineApi, H as HerdrError } from '../../../nitro/nitro.mjs';
import { v as validMachineOrder, c as currentMachineKeys, w as writeMachineOrder } from '../../../_/machineOrder.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const order_post = defineApi(async (_event, body) => {
  const order = body.order;
  if (!validMachineOrder(order, currentMachineKeys())) throw new HerdrError("bad_machine_order", "Invalid machine order");
  await writeMachineOrder(order);
  return { order };
});

export { order_post as default };
//# sourceMappingURL=order.post.mjs.map

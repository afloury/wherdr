import { a as defineApi, i as getQuery, _ as MACHINE_KEY_RE, H as HerdrError, $ as getMachine } from '../../../nitro/nitro.mjs';
import { a as awakeStatus, s as sleepAssertions } from '../../../_/awake.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const awake_get = defineApi(async (event) => {
  const query = getQuery(event);
  const key = typeof query.key === "string" ? query.key : null;
  if (key === null || key !== "" && !MACHINE_KEY_RE.test(key)) throw new HerdrError("bad_machine", "unknown machine");
  const machine = getMachine(key);
  if (!machine || machine.status !== "online") throw new HerdrError("bad_machine", "Machine unreachable");
  const status = await awakeStatus(machine);
  return { ...status, assertions: query.diagnostic === "1" ? await sleepAssertions(machine) : [] };
});

export { awake_get as default };
//# sourceMappingURL=awake.get.mjs.map

import { a as defineApi, _ as MACHINE_KEY_RE, $ as getMachine, H as HerdrError, aJ as renameMachine } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const rename_post = defineApi(async (_event, body) => {
  const key = typeof body.key === "string" ? body.key : null;
  if (key === null || key !== "" && !MACHINE_KEY_RE.test(key) || !getMachine(key)) {
    throw new HerdrError("bad_machine", "unknown machine");
  }
  const label = typeof body.label === "string" ? body.label.replace(/\s+/g, " ").trim() : "";
  if (!label || label.length > 40) throw new HerdrError("bad_label", "Invalid machine name (40 characters max)");
  await renameMachine(key, label);
  return { ok: true, label };
});

export { rename_post as default };
//# sourceMappingURL=rename.post.mjs.map

import { a as defineApi, _ as MACHINE_KEY_RE, H as HerdrError, $ as getMachine, b1 as projectsProgramVersion, b2 as updateProjectsPlugin, b3 as installProjectsPlugin } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const projects_post = defineApi(async (_event, body) => {
  const key = body.machine;
  if (typeof key !== "string" || key !== "" && !MACHINE_KEY_RE.test(key)) throw new HerdrError("bad_machine", "unknown machine");
  const machine = getMachine(key);
  if (!machine) throw new HerdrError("bad_machine", "unknown machine");
  if (body.update === true) {
    const program = await projectsProgramVersion(machine).catch(() => null);
    return { output: await updateProjectsPlugin(machine, program) };
  }
  return { output: await installProjectsPlugin(machine) };
});

export { projects_post as default };
//# sourceMappingURL=projects.post.mjs.map

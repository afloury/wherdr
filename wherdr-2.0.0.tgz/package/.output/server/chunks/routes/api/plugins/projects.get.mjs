import { a as defineApi, i as getQuery, _ as MACHINE_KEY_RE, H as HerdrError, $ as getMachine, b0 as projectsPluginState, b1 as projectsProgramVersion } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const projects_get = defineApi(async (event) => {
  const key = getQuery(event).machine;
  if (typeof key !== "string" || key !== "" && !MACHINE_KEY_RE.test(key)) throw new HerdrError("bad_machine", "unknown machine");
  const machine = getMachine(key);
  if (!machine) throw new HerdrError("bad_machine", "unknown machine");
  const state = await projectsPluginState(machine);
  const program = state.status === "ready" ? await projectsProgramVersion(machine).catch(() => null) : null;
  return { ...state, program };
});

export { projects_get as default };
//# sourceMappingURL=projects.get.mjs.map

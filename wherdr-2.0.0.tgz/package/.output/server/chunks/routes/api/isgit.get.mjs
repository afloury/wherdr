import { a as defineApi, i as getQuery, m as machineFor, aE as underHome, aF as isGitRepo } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const isgit_get = defineApi(async (event) => {
  const q = getQuery(event);
  const m = machineFor(q.machine);
  const dir = underHome(String(q.path || "") || m.home, m.home);
  if (!dir) return { git: false };
  return { git: await isGitRepo(dir, m) };
});

export { isgit_get as default };
//# sourceMappingURL=isgit.get.mjs.map

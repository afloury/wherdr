import { H as HerdrError, J as keysFor, K as parseChoices, L as parseOmpField, a as defineApi, P as PANE_RE, f as findPane, M as withPaneLock, N as selfUpdates, O as restarting, Q as updateChoices, R as UPDATE_LABELS, S as updateRestartPlan, T as restarts, p as poll, h as herdr, y as transcripts, b as screenChoices, V as usesTerminalException, W as sameQuestion, X as sleep, g as choicesCache } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const OPEN_MS = 3e3;
const answering = /* @__PURE__ */ new Set();
async function answerFree(d, paneId, choices, index, answer2, agent) {
  if (answering.has(paneId)) throw new HerdrError("busy", "An answer is already being sent.");
  answering.add(paneId);
  try {
    if (agent === "claude") await typeClaudeAnswer(d, paneId, choices, index, answer2);
    else await typeAnswer(d, paneId, choices, index, answer2);
  } finally {
    answering.delete(paneId);
  }
}
async function typeAnswer(d, paneId, choices, index, answer2) {
  const keys = (k) => d.call("pane.send_input", { pane_id: paneId, keys: k });
  const field = async () => {
    var _a, _b;
    return parseOmpField((_b = (_a = await d.call("pane.read", { pane_id: paneId, source: "detection" }, 4e3)) == null ? void 0 : _a.read) == null ? void 0 : _b.text);
  };
  if (!choices.typing) await keys(keysFor(choices, index));
  let f = await field();
  for (const end = d.now() + OPEN_MS; !f && d.now() < end; ) {
    await d.sleep(100);
    f = await field();
  }
  for (let round = 0; f && f.value; round++) {
    if (round === 3) throw new HerdrError("stale", "omp\u2019s answer field could not be cleared \u2014 check the current screen.");
    await keys(Array.from({ length: f.rows + 1 }, () => ["ctrl+k", "ctrl+u"]).flat());
    await d.sleep(150);
    f = await field();
  }
  if (!f) throw new HerdrError("stale", "omp\u2019s answer field did not open \u2014 check the current screen.");
  const lines = answer2.replace(/\u001b\[[0-?]*[ -/]*[@-~]/g, "").replace(/\t/g, "    ").replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f-\u009f]/g, "").split(/\r\n|[\r\n\u2028\u2029]/);
  const closed = new HerdrError("stale", "omp\u2019s answer field closed \u2014 answer not submitted, check the current screen.");
  for (let i = 0; i < lines.length; i++) {
    if (i) {
      if (!await field()) throw closed;
      await keys(["shift+enter"]);
    }
    if (lines[i]) await d.call("pane.send_input", { pane_id: paneId, text: lines[i] });
  }
  f = await field();
  for (const end = d.now() + OPEN_MS; f && !f.value && d.now() < end; ) {
    await d.sleep(100);
    f = await field();
  }
  if (!f || !f.value) throw closed;
  await keys(["enter"]);
}
const squash = (s) => s.replace(/\s+/g, "");
async function typeClaudeAnswer(d, paneId, choices, index, answer2) {
  const keys = (k) => d.call("pane.send_input", { pane_id: paneId, keys: k });
  const field = async () => {
    var _a, _b;
    const c = parseChoices((_b = (_a = await d.call("pane.read", { pane_id: paneId, source: "detection" }, 4e3)) == null ? void 0 : _a.read) == null ? void 0 : _b.text);
    const o = c && c.options[c.cursor];
    return o && o.free ? { value: o.hint || "", checked: o.checked, question: c.question } : null;
  };
  const moves = keysFor(choices, index).slice(0, -1);
  if (moves.length) await keys(moves);
  let f = await field();
  for (const end = d.now() + OPEN_MS; !f && d.now() < end; ) {
    await d.sleep(100);
    f = await field();
  }
  if (!f) throw new HerdrError("stale", "Claude\u2019s answer field could not be reached \u2014 check the current screen.");
  for (let round = 0; f && f.value; round++) {
    if (round === 4) throw new HerdrError("stale", "Claude\u2019s answer field could not be cleared \u2014 check the current screen.");
    await keys(["ctrl+u"]);
    await d.sleep(150);
    f = await field();
  }
  if (!f) throw new HerdrError("stale", "Claude\u2019s answer field could not be cleared \u2014 check the current screen.");
  const text = answer2.replace(/\u001b\[[0-?]*[ -/]*[@-~]/g, "").replace(/[\u0000-\u001f\u007f-\u009f\u2028\u2029]+/g, " ").replace(/\s+/g, " ").trim();
  await d.call("pane.send_input", { pane_id: paneId, text });
  const want = squash(text).slice(0, 24);
  f = await field();
  for (const end = d.now() + OPEN_MS; f && !squash(f.value).startsWith(want) && d.now() < end; ) {
    await d.sleep(100);
    f = await field();
  }
  if (!f || !squash(f.value).startsWith(want)) throw new HerdrError("stale", "Claude\u2019s answer field closed \u2014 answer not submitted, check the current screen.");
  if (f.checked !== void 0 && f.checked !== false) return;
  if (text.endsWith("\\")) {
    await keys(["ctrl+a"]);
    await d.sleep(50);
  }
  await keys(["enter"]);
  const still = (g2) => Boolean(g2) && g2.question === f.question;
  let g = await field();
  for (const end = d.now() + OPEN_MS; still(g) && d.now() < end; ) {
    await d.sleep(100);
    g = await field();
  }
  if (still(g)) throw new HerdrError("stale", "Claude kept the answer in its field \u2014 answer not submitted, check the current screen.");
}

const choose_post = defineApi(async (event, b) => {
  var _a;
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  if ((_a = findPane(b.pane_id)) == null ? void 0 : _a.stopped) {
    return withPaneLock(b.pane_id, async () => {
      const p = findPane(b.pane_id);
      const launch = await selfUpdates.check(b.pane_id);
      if (!(p == null ? void 0 : p.stopped) || !launch || restarting(p.id)) throw new HerdrError("stale", "The pane is not at an empty shell prompt. Check its terminal.");
      const choice = updateChoices(launch)[Number(b.index)];
      if (!choice || UPDATE_LABELS[choice] !== b.label || b.text) throw new HerdrError("stale", "The question has changed \u2014 check the current screen.");
      const plan = updateRestartPlan(launch, choice);
      restarts.set(p.id, { phase: "starting", agent: "codex", session: launch.session, at: Date.now() });
      poll();
      try {
        await herdr("agent.start", { name: p.name || `codex-${Date.now().toString(36)}`, kind: "codex", pane_id: p.id, args: plan.args, timeout_ms: 6e4 }, 75e3);
      } catch (e) {
        if (!(e instanceof HerdrError) || e.code !== "agent_not_ready") {
          restarts.delete(p.id);
          setTimeout(poll, 0);
          throw e;
        }
      }
      selfUpdates.clear(p.id);
      restarts.set(p.id, { phase: "starting", agent: "codex", session: launch.session, at: Date.now(), started: true });
      setTimeout(poll, 0);
      return { ok: true };
    });
  }
  try {
    const pane = findPane(b.pane_id);
    const asked = pane && pane.agent === "claude" ? await transcripts.pendingClaudeQuestions(pane).catch(() => []) : [];
    const r = await herdr("pane.read", { pane_id: b.pane_id, source: "detection" }, 4e3);
    const text = r.read && r.read.text;
    const choices = screenChoices(text, pane == null ? void 0 : pane.agent, asked);
    const i = Number(b.index);
    const option = choices && choices.options[i];
    const answer = typeof b.text === "string" ? b.text.trim() : "";
    if (!choices || !b.identity || choices.identity !== b.identity || usesTerminalException({ text: String(text || ""), agent: pane == null ? void 0 : pane.agent, status: pane == null ? void 0 : pane.status }) || !option || option.label !== b.label || answer && !option.free || option.free && !sameQuestion(choices.question, typeof b.question === "string" ? b.question : null)) {
      throw new HerdrError("stale", "The question has changed \u2014 check the current screen.");
    }
    if (option.free && !answer) throw new HerdrError("bad_text", "Write your answer before sending it.");
    if (option.free) await answerFree({ call: herdr, sleep, now: Date.now }, b.pane_id, choices, i, answer, pane == null ? void 0 : pane.agent);
    else await herdr("pane.send_input", { pane_id: b.pane_id, keys: keysFor(choices, i) });
  } finally {
    choicesCache.delete(b.pane_id);
    setTimeout(poll, 0);
  }
  return { ok: true };
});

export { choose_post as default };
//# sourceMappingURL=choose.post.mjs.map

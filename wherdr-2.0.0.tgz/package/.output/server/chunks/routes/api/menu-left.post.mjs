import { a as defineApi, P as PANE_RE, H as HerdrError, aL as closeLeftMenu } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const menuLeft_post = defineApi(async (event, b) => {
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  if (b.action !== "close" && b.action !== "send") throw new HerdrError("bad_action", "Invalid action");
  return { ok: true, ...await closeLeftMenu(b.pane_id, b.action === "send") };
});

export { menuLeft_post as default };
//# sourceMappingURL=menu-left.post.mjs.map

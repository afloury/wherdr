import { a as defineApi, P as PANE_RE, H as HerdrError, f as findPane, a2 as codexStatus } from '../../nitro/nitro.mjs';
import { u as updateCodexInPane } from '../../_/restart.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const codexUpdate_post = defineApi(async (event, b) => {
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  const p = findPane(b.pane_id);
  if (!p || p.agent !== "codex") throw new HerdrError("bad_pane", "agent not found");
  if (b.dismiss === true) {
    codexStatus.dismiss(p);
    return { ok: true };
  }
  const r = await codexStatus.startUpdate(p, (command) => updateCodexInPane(p.id, command));
  return { ok: true, command: r.command, method: r.method };
});

export { codexUpdate_post as default };
//# sourceMappingURL=codex-update.post.mjs.map

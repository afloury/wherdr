import { a as defineApi, P as PANE_RE, H as HerdrError, M as withPaneLock, f as findPane, aB as interruptAgent, X as sleep, h as herdr, aC as takeBackFromClaude, aD as takeBack, aa as log, p as poll } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const interrupt_post = defineApi(async (event, b) => {
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  return withPaneLock(b.pane_id, async () => {
    const p = findPane(b.pane_id);
    if (!p || !p.agent) throw new HerdrError("bad_pane", "No agent in this pane");
    const r = await interruptAgent({ call: (m, params, t) => herdr(m, params, t), sleep, now: Date.now }, p);
    let restored;
    let lost = 0;
    if (r.stopped && b.restore === true && p.agent === "claude") {
      const item = await takeBackFromClaude(p);
      if (item) {
        const back = takeBack(p.id, item);
        restored = back.text;
        lost = back.lost;
        log(`interrupted prompt taken back on ${p.id}`);
      }
    }
    setTimeout(poll, 100);
    return { ok: true, ...r, ...restored !== void 0 ? { restored } : {}, ...lost ? { lost } : {} };
  });
});

export { interrupt_post as default };
//# sourceMappingURL=interrupt.post.mjs.map

import { a as defineApi, H as HerdrError } from '../../nitro/nitro.mjs';
import { w as writeOnboarding } from '../../_/onboarding.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const onboarding_post = defineApi((_event, body) => {
  if (typeof (body == null ? void 0 : body.done) !== "boolean") throw new HerdrError("bad_request", "done must be true or false");
  return writeOnboarding(body.done);
});

export { onboarding_post as default };
//# sourceMappingURL=onboarding.post.mjs.map

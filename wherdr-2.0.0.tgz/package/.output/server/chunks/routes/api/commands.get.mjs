import { a as defineApi, f as findPane, i as getQuery, H as HerdrError, q as machineOfPane, ae as builtinCommands, af as slashCommands, aa as log } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const commands_get = defineApi(async (event) => {
  const p = findPane(String(getQuery(event).pane || ""));
  if (!p) throw new HerdrError("bad_pane", "Pane not found");
  const m = machineOfPane(p.id);
  if (!p.agent || !m || !m.home) return { commands: [] };
  if (!m.local && m.status !== "online") return { commands: builtinCommands(p.agent), partial: true };
  try {
    const r = await slashCommands({ key: m.key, fs: m.fs, exec: m.exec, home: m.home, kind: p.agent, cwd: p.cwd });
    return r.denied ? { ...r, remote: !m.local } : r;
  } catch (e) {
    log(`commands ${p.id}: ${e.message}`);
    return { commands: builtinCommands(p.agent), partial: true };
  }
});

export { commands_get as default };
//# sourceMappingURL=commands.get.mjs.map

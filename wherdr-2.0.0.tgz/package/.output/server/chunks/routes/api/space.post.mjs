import { bJ as PANE_DIRECTIONS, a_ as splitId, br as PANE_RE, a as defineApi, H as HerdrError, aa as log, p as poll, aZ as herdrOn } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, key + "" , value);
const WORKSPACE_RE = /^(?:[0-9a-f]{4,32}~)?w[0-9a-z]+$/i;
const TAB_RE = /^(?:[0-9a-f]{4,32}~)?w[0-9a-z]+:t[0-9a-z]+$/i;
const LABEL_MAX = 60;
class SpaceActionError extends Error {
  constructor(code, message) {
    super(message);
    __publicField(this, "code");
    this.code = code;
  }
}
const fail = (code, message) => {
  throw new SpaceActionError(code, message);
};
const cleanLabel = (v) => String(v != null ? v : "").replace(/\s+/g, " ").trim().slice(0, LABEL_MAX);
function idOf(v, re, what) {
  const s = String(v != null ? v : "");
  if (!re.test(s)) fail("bad_id", `invalid ${what}`);
  return splitId(s);
}
const cleanCwd = (x) => typeof x === "string" && x.startsWith("/") && x.length <= 4096 && !x.includes("\0") ? x : null;
function spaceCall(body) {
  var _a;
  const b = body && typeof body === "object" ? body : {};
  const op = String(b.op || "");
  switch (op) {
    case "tab.create": {
      const w = idOf(b.workspace_id, WORKSPACE_RE, "workspace");
      const label = cleanLabel(b.label);
      const cwd = cleanCwd(b.cwd);
      return { machine: w.machine, method: "tab.create", params: { workspace_id: w.local, ...label ? { label } : {}, ...cwd ? { cwd } : {}, focus: false } };
    }
    case "workspace.rename":
    case "tab.rename": {
      const isTab = op === "tab.rename";
      const x = isTab ? idOf(b.tab_id, TAB_RE, "tab") : idOf(b.workspace_id, WORKSPACE_RE, "workspace");
      const label = cleanLabel(b.label);
      if (!label) fail("bad_label", "empty name");
      return { machine: x.machine, method: op, params: { [isTab ? "tab_id" : "workspace_id"]: x.local, label } };
    }
    case "workspace.close": {
      const w = idOf(b.workspace_id, WORKSPACE_RE, "workspace");
      return { machine: w.machine, method: op, params: { workspace_id: w.local, ...b.close_group === true ? { close_group: true } : {} } };
    }
    case "tab.close": {
      const x = idOf(b.tab_id, TAB_RE, "tab");
      if (b.close_group === true) return { machine: x.machine, method: "workspace.close", params: { workspace_id: x.local.split(":")[0], close_group: true } };
      return { machine: x.machine, method: op, params: { tab_id: x.local } };
    }
    case "pane.split": {
      const p = idOf(b.pane_id, PANE_RE, "pane");
      const direction = b.direction;
      if (direction !== "right" && direction !== "down") fail("bad_direction", "invalid direction");
      const cwd = cleanCwd(b.cwd);
      return { machine: p.machine, method: op, params: { target_pane_id: p.local, direction, ...cwd ? { cwd } : {}, focus: false } };
    }
    case "pane.move": {
      const p = idOf(b.pane_id, PANE_RE, "pane");
      const to = b.to;
      let destination;
      if (to === "new_tab") destination = { type: "new_tab", workspace_id: p.local.split(":")[0] };
      else if (to === "new_workspace") destination = { type: "new_workspace" };
      else if (to && typeof to === "object") {
        const x = idOf(to.tab_id, TAB_RE, "tab");
        if (x.machine !== p.machine) fail("bad_machine", "tab on another machine");
        destination = { type: "tab", tab_id: x.local, split: "right" };
      } else return fail("bad_destination", "invalid destination");
      return { machine: p.machine, method: op, params: { pane_id: p.local, destination, focus: false } };
    }
    case "pane.swap": {
      const p = idOf(b.pane_id, PANE_RE, "pane");
      const direction = b.direction;
      if (!PANE_DIRECTIONS.includes(direction)) fail("bad_direction", "invalid direction");
      return { machine: p.machine, method: op, params: { pane_id: p.local, direction } };
    }
    case "pane.drop": {
      const p = idOf(b.pane_id, PANE_RE, "pane");
      const x = idOf(b.target_pane_id, PANE_RE, "pane");
      if (x.machine !== p.machine) fail("bad_machine", "pane on another machine");
      const side = b.side;
      if (side !== "center" && !PANE_DIRECTIONS.includes(side)) fail("bad_direction", "invalid direction");
      return { machine: p.machine, method: op, params: { pane_id: p.local, target_pane_id: x.local, side } };
    }
    case "layout.ratio": {
      const x = idOf(b.tab_id, TAB_RE, "tab");
      const path = String((_a = b.path) != null ? _a : "");
      if (!/^[01]{0,32}$/.test(path)) fail("bad_path", "invalid split");
      const ratio = Number(b.ratio);
      if (!Number.isFinite(ratio) || ratio <= 0 || ratio >= 1) fail("bad_ratio", "invalid ratio");
      return {
        machine: x.machine,
        method: "layout.set_split_ratio",
        params: { tab_id: x.local, path: [...path].map((c) => c === "1"), ratio: Math.round(Math.min(0.95, Math.max(0.05, ratio)) * 1e3) / 1e3 }
      };
    }
    case "workspace.move": {
      const w = idOf(b.workspace_id, WORKSPACE_RE, "workspace");
      let before = null;
      if (b.before_workspace_id != null) {
        const x = idOf(b.before_workspace_id, WORKSPACE_RE, "workspace");
        if (x.machine !== w.machine) fail("bad_machine", "space on another machine");
        if (x.local === w.local) fail("bad_destination", "invalid destination");
        before = x.local;
      }
      return { machine: w.machine, method: "workspace.move_block", params: { workspace_ids: [w.local], before_workspace_id: before } };
    }
    default:
      return fail("bad_op", `unknown action: ${op}`);
  }
}
function spaceResult(call, r) {
  var _a, _b, _c, _d, _e;
  const id = (x) => x == null ? void 0 : call.machine ? `${call.machine}~${x}` : String(x);
  if (!r || typeof r !== "object") return {};
  if (call.method === "tab.create") return { tab_id: id((_a = r.tab) == null ? void 0 : _a.tab_id), pane_id: id((_b = r.root_pane) == null ? void 0 : _b.pane_id) };
  if (call.method === "pane.split") return { pane_id: id((_c = r.pane) == null ? void 0 : _c.pane_id), tab_id: id((_d = r.pane) == null ? void 0 : _d.tab_id) };
  if (call.method === "pane.move") {
    const p = (_e = r.move_result) == null ? void 0 : _e.pane;
    return { pane_id: id(p == null ? void 0 : p.pane_id), tab_id: id(p == null ? void 0 : p.tab_id) };
  }
  return {};
}
function swapSteps(snap, pane, target) {
  if (!target || target === pane) fail("no_neighbor", "no pane on that side");
  const layouts = Array.isArray(snap == null ? void 0 : snap.layouts) ? snap.layouts : [];
  const tab = layouts.find((l) => {
    var _a;
    return (_a = l.panes) == null ? void 0 : _a.some((p) => p.pane_id === pane);
  });
  if (!tab || !tab.panes.some((p) => p.pane_id === target)) fail("no_neighbor", "no pane on that side");
  if (tab.zoomed) fail("zoomed", "a pane is zoomed in this tab");
  const tabFocus = tab.focused_pane_id || null;
  const [source, other] = tabFocus === target ? [target, pane] : [pane, target];
  return [{ method: "pane.swap", params: { source_pane_id: source, target_pane_id: other } }, ...refocus(snap, tab, source)];
}
function refocus(snap, tab, cur) {
  const layouts = Array.isArray(snap == null ? void 0 : snap.layouts) ? snap.layouts : [];
  const ws = (Array.isArray(snap == null ? void 0 : snap.workspaces) ? snap.workspaces : []).find((w) => w.workspace_id === tab.workspace_id);
  const activeTab = layouts.find((l) => l.tab_id === (ws == null ? void 0 : ws.active_tab_id));
  const steps = [];
  for (const f of [tab.focused_pane_id || null, (activeTab == null ? void 0 : activeTab.focused_pane_id) || null, (snap == null ? void 0 : snap.focused_pane_id) || null]) {
    if (!f || f === cur) continue;
    steps.push({ method: "pane.focus", params: { pane_id: f } });
    cur = f;
  }
  return steps;
}
function dropSteps(snap, pane, target, side) {
  if (side === "center") return swapSteps(snap, pane, target);
  if (!target || target === pane) fail("no_neighbor", "same pane");
  const layouts = Array.isArray(snap == null ? void 0 : snap.layouts) ? snap.layouts : [];
  const tab = layouts.find((l) => {
    var _a;
    return (_a = l.panes) == null ? void 0 : _a.some((p) => p.pane_id === pane);
  });
  if (!tab || !tab.panes.some((p) => p.pane_id === target)) fail("no_neighbor", "pane in another tab");
  if (tab.zoomed) fail("zoomed", "a pane is zoomed in this tab");
  const before = side === "left" || side === "up";
  const steps = [
    { method: "pane.move", params: { pane_id: pane, destination: { type: "new_tab", workspace_id: tab.workspace_id }, focus: false } },
    { method: "pane.move", params: { pane_id: pane, destination: { type: "tab", tab_id: tab.tab_id, split: side === "left" || side === "right" ? "right" : "down", target_pane_id: target }, focus: false } }
  ];
  if (before) steps.push({ method: "pane.swap", params: { source_pane_id: pane, target_pane_id: target } });
  return [...steps, ...refocus(snap, tab, before ? pane : null)];
}
function verifySpaceRename(call, snapshot) {
  var _a;
  const tab = call.method === "tab.rename";
  if (!tab && call.method !== "workspace.rename") return;
  const key = tab ? "tab_id" : "workspace_id";
  const target = (_a = tab ? snapshot == null ? void 0 : snapshot.tabs : snapshot == null ? void 0 : snapshot.workspaces) == null ? void 0 : _a.find((x) => x[key] === call.params[key]);
  if (!target || target.label !== call.params.label) throw new SpaceActionError("rename_failed", "Rename failed. The name was not changed.");
}

const space_post = defineApi(async (_event, body) => {
  let call;
  try {
    call = spaceCall(body);
  } catch (e) {
    if (e instanceof SpaceActionError) throw new HerdrError(e.code, e.message);
    throw e;
  }
  if (call.method === "pane.swap") {
    await swapPanes(call.machine, String(call.params.pane_id), call.params.direction);
    log(`space: pane.swap${call.machine ? ` (${call.machine})` : ""}`);
    poll();
    return { ok: true };
  }
  if (call.method === "pane.drop") {
    const { pane_id: pane, target_pane_id: target, side } = call.params;
    const snap = await herdrOn(call.machine, "session.snapshot", {}, 5e3);
    await runSteps(call.machine, stepsOf(() => dropSteps((snap == null ? void 0 : snap.snapshot) || snap, pane, target, side)));
    log(`space: pane.drop ${side}${call.machine ? ` (${call.machine})` : ""}`);
    poll();
    return { ok: true };
  }
  const r = await herdrOn(call.machine, call.method, call.params);
  if (call.method === "workspace.rename" || call.method === "tab.rename") {
    const snap = await herdrOn(call.machine, "session.snapshot", {}, 5e3);
    stepsOf(() => {
      verifySpaceRename(call, (snap == null ? void 0 : snap.snapshot) || snap);
      return [];
    });
  }
  log(`space: ${call.method}${call.machine ? ` (${call.machine})` : ""}`);
  poll();
  return { ok: true, ...spaceResult(call, r) };
});
async function swapPanes(machine, pane, direction) {
  const [snap, nb] = await Promise.all([
    herdrOn(machine, "session.snapshot", {}, 5e3),
    herdrOn(machine, "pane.neighbor", { pane_id: pane, direction })
  ]);
  await runSteps(machine, stepsOf(() => {
    var _a, _b;
    return swapSteps((snap == null ? void 0 : snap.snapshot) || snap, pane, (_b = (_a = nb == null ? void 0 : nb.neighbor) == null ? void 0 : _a.neighbor_pane_id) != null ? _b : null);
  }));
}
function stepsOf(f) {
  try {
    return f();
  } catch (e) {
    if (e instanceof SpaceActionError) throw new HerdrError(e.code, e.message);
    throw e;
  }
}
async function runSteps(machine, steps) {
  var _a;
  const renamed = /* @__PURE__ */ new Map();
  const fix = (v) => {
    var _a2;
    return typeof v === "string" ? (_a2 = renamed.get(v)) != null ? _a2 : v : v && typeof v === "object" && !Array.isArray(v) ? Object.fromEntries(Object.entries(v).map(([k, x]) => [k, fix(x)])) : v;
  };
  for (const s of steps) {
    const r = await herdrOn(machine, s.method, fix(s.params));
    const m = r == null ? void 0 : r.move_result;
    if ((m == null ? void 0 : m.previous_pane_id) && ((_a = m.pane) == null ? void 0 : _a.pane_id) && m.previous_pane_id !== m.pane.pane_id) {
      for (const [k, v] of renamed) if (v === m.previous_pane_id) renamed.set(k, m.pane.pane_id);
      renamed.set(m.previous_pane_id, m.pane.pane_id);
    }
  }
}

export { space_post as default };
//# sourceMappingURL=space.post.mjs.map

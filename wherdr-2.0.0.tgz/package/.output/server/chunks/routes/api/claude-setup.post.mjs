import { a as defineApi, H as HerdrError, Y as writeDismissed, Z as forgetQuotas } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const claudeSetup_post = defineApi((_event, body) => {
  const keys = Array.isArray(body == null ? void 0 : body.keys) ? body.keys.filter((k) => typeof k === "string").slice(0, 64) : null;
  if (!keys || typeof (body == null ? void 0 : body.dismissed) !== "boolean") throw new HerdrError("bad_request", "keys and dismissed are required");
  const dismissed = writeDismissed(keys, body.dismissed);
  forgetQuotas();
  return { dismissed };
});

export { claudeSetup_post as default };
//# sourceMappingURL=claude-setup.post.mjs.map

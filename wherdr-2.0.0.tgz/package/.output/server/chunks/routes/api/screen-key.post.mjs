import { a as defineApi, P as PANE_RE, H as HerdrError, h as herdr, bs as parseWaitScreen, K as parseChoices, bt as waitIdentity, g as choicesCache, p as poll } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const screenKey_post = defineApi(async (event, b) => {
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  try {
    const r = await herdr("pane.read", { pane_id: b.pane_id, source: "detection" }, 4e3);
    const text = r.read && r.read.text;
    const screen = parseWaitScreen(text, { choices: Boolean(parseChoices(text, { strict: true })) });
    const a = screen && screen.actions.find((x) => x.key === b.key && x.label === b.label);
    if (!a || !b.identity || !screen || waitIdentity(screen) !== b.identity) throw new HerdrError("stale", "The screen has changed \u2014 check the current screen.");
    await herdr("pane.send_input", { pane_id: b.pane_id, keys: [a.key] });
    return { ok: true };
  } finally {
    choicesCache.delete(b.pane_id);
    setTimeout(poll, 0);
  }
});

export { screenKey_post as default };
//# sourceMappingURL=screen-key.post.mjs.map

import { a as defineApi, H as HerdrError, bE as openSession } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const sessions_post = defineApi(async (_event, body) => {
  if (typeof body.machine !== "string" || typeof body.name !== "string") throw new HerdrError("bad_session", "Invalid session");
  return { session: await openSession(body.machine, body.name) };
});

export { sessions_post as default };
//# sourceMappingURL=sessions.post.mjs.map

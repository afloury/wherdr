import { a as defineApi, i as getQuery, P as PANE_RE, H as HerdrError, au as listEfforts, f as findPane, at as refreshModel } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const efforts_get = defineApi(async (event) => {
  const pane = String(getQuery(event).pane || "");
  if (!PANE_RE.test(pane)) throw new HerdrError("bad_pane", "Invalid pane");
  const result = await listEfforts(pane);
  const p = findPane(pane);
  if (p && result.current) refreshModel(p);
  return result;
});

export { efforts_get as default };
//# sourceMappingURL=efforts.get.mjs.map

import { U as UPLOAD_DIR, u as uploadNames, n as runHerdrCli, o as parseIntegrationStatus, a as defineApi, i as getQuery, f as findPane, H as HerdrError, q as machineOfPane, t as fmt, v as takenBackOf, x as chatDelta, y as transcripts, z as missingIntegration, B as multiMachine, C as integrationCommand, D as chatPasted, E as withoutTakenBack, F as withSentText, G as currentModel } from '../../nitro/nitro.mjs';
import { createHash } from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import 'node:http';
import 'node:https';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const UPLOAD_PATH = /\.cache\/herdr-web\/uploads\/([\w-]+\.[a-z]+)/g;
const CACHE_MAX = 500;
const cache$1 = /* @__PURE__ */ new Map();
async function uploadHash(dir, name) {
  const key = `${dir}
${name}`;
  if (cache$1.has(key)) return cache$1.get(key);
  let hash = null;
  try {
    hash = createHash("sha256").update(await fs.readFile(path.join(dir, path.basename(name)))).digest("hex");
  } catch {
    hash = null;
  }
  if (cache$1.size >= CACHE_MAX) cache$1.delete(cache$1.keys().next().value);
  cache$1.set(key, hash);
  return hash;
}
async function addUploadHashes(items, dir = UPLOAD_DIR) {
  var _a;
  for (const it of items) {
    if (it.role === "user") {
      const names = uploadNames(it.text);
      if (!names.length) continue;
      const own = (await Promise.all(names.map((n) => uploadHash(dir, n)))).filter((h) => !!h);
      const hashes = [...it.hashes || [], ...own.filter((h) => {
        var _a2;
        return !((_a2 = it.hashes) == null ? void 0 : _a2.includes(h));
      })];
      if (hashes.length) it.hashes = hashes;
    } else if (it.images === 1) {
      const names = [...new Set([...`${it.text}
${((_a = it.omp) == null ? void 0 : _a.target) || ""}`.matchAll(UPLOAD_PATH)].map((m) => m[1]))];
      if (names.length !== 1) continue;
      const h = await uploadHash(dir, names[0]);
      if (h) it.hashes = [h];
    }
  }
}

const ttl = Number(process.env.WHERDR_INTEGRATION_TTL_MS);
const TTL_MS = Number.isFinite(ttl) && ttl >= 0 ? ttl : 6e4;
const cache = /* @__PURE__ */ new Map();
const keyOf = (m) => m.local ? "" : `${m.target || m.key}`;
async function integrationStatus(m) {
  const key = keyOf(m);
  const hit = cache.get(key);
  if (hit == null ? void 0 : hit.pending) return hit.pending;
  if (hit && Date.now() - hit.at < TTL_MS) return hit.status;
  const pending = runHerdrCli(m, ["integration", "status"], 8e3).then((r) => r.code === 0 ? parseIntegrationStatus(r.stdout.toString("utf8")) : null).catch(() => null).then((status) => {
    cache.set(key, { at: Date.now(), status: status && Object.keys(status).length ? status : null });
    return cache.get(key).status;
  });
  cache.set(key, { at: (hit == null ? void 0 : hit.at) || 0, status: (hit == null ? void 0 : hit.status) || null, pending });
  return pending;
}

const chat_get = defineApi(async (event) => {
  const q = getQuery(event);
  const p = findPane(String(q.pane || ""));
  if (!p) throw new HerdrError("bad_pane", "Pane not found");
  const m = machineOfPane(p.id);
  if (m && !m.local && m.status !== "online") throw new HerdrError("unreachable", fmt("{machine} is unreachable", { machine: m.label }));
  const num = (k) => q[k] !== void 0 ? Math.max(0, Number(q[k]) || 0) : null;
  const { hidden, seq } = takenBackOf(p.id);
  const mark = hidden.length ? `~${seq}` : "";
  const sent = String(q.since || "");
  const count = num("n");
  const since = chatDelta.sinceOf(p.id, sent, count);
  const from = num("from");
  const r = await transcripts.chat(p, {
    since: mark ? since.endsWith(mark) ? since.slice(0, -mark.length) : "" : since,
    from,
    // re-read from this byte (bottom of the conversation already shown)
    anchor: sent,
    // join check above `from`, even for a list the server forgot
    before: num("before")
    // older slice, ending at this byte
  });
  if (!r.available && r.reason === "not_found" && m && p.agent && !p.agentSession && missingIntegration(p, await integrationStatus(m), m.transcripts.wasActive(p.id, p.agent))) {
    return { ...r, reason: "no_integration", integration: { agent: p.agent, command: integrationCommand(p.agent), machine: multiMachine() ? m.label : null } };
  }
  if (r.token) r.token += mark;
  if (r.unchanged) r.token = sent;
  if (r.items) {
    r.items = chatPasted(withoutTakenBack(r.items, hidden));
    await addUploadHashes(r.items);
    if (r.token && !r.older) {
      const d = chatDelta.reply(p.id, r.token, r.items, sent, count, from !== null && r.start === from && !r.rewritten);
      r.token = d.token;
      r.items = d.items;
      if (d.keep !== void 0) r.keep = d.keep;
    }
  }
  if (r.queue && r.queue.length) r.queue = withSentText(p.id, r.queue);
  return r.available ? { ...r, model: await currentModel(p).catch(() => null) } : r;
});

export { chat_get as default };
//# sourceMappingURL=chat.get.mjs.map

import { a as defineApi, f as findPane, i as getQuery, H as HerdrError, m as machineFor } from '../../../nitro/nitro.mjs';
import { a as readChangeStatus } from '../../../_/changes.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const status_get = defineApi(async (event) => {
  const p = findPane(String(getQuery(event).pane || ""));
  if (!p) throw new HerdrError("bad_pane", "Pane not found");
  if (!p.cwd) throw new HerdrError("bad_cwd", "This pane\u2019s folder is unknown");
  return readChangeStatus(machineFor(p.machine), p.cwd);
});

export { status_get as default };
//# sourceMappingURL=status.get.mjs.map

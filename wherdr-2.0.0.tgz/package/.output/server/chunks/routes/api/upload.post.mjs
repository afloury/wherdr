import { a as defineApi, i as getQuery, av as saveUpload, P as PANE_RE } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const upload_post = defineApi((event, b) => {
  const pane = String(getQuery(event).pane || "");
  return saveUpload(b.data, b.ctype, PANE_RE.test(pane) ? pane : null);
}, { raw: /^image\/(jpeg|png|webp|gif|heic)$/ });

export { upload_post as default };
//# sourceMappingURL=upload.post.mjs.map

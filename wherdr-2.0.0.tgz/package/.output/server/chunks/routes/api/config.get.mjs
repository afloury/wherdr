import { ag as HOME, a as defineApi, ah as localMachine, ai as openNetworkMode, aj as readSubs, ak as vapidPublicKey, al as pushReady, am as machineConfigs, an as recentDirs, ao as installedAgentKinds, l as localMachineLabel } from '../../nitro/nitro.mjs';
import fs from 'node:fs';
import path from 'node:path';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const COLOR = /^(#[0-9a-f]{3,8}|[a-z]{3,20}|rgb\(\s*\d{1,3}\s*,\s*\d{1,3}\s*,\s*\d{1,3}\s*\))$/i;
const NAME = /^[a-z0-9][a-z0-9-]{0,39}$/i;
function parseHerdrTheme(toml) {
  var _a;
  const out = { name: null, autoSwitch: false, darkName: null, lightName: null, custom: {}, customLight: {}, customDark: {} };
  let table = "";
  for (const raw of String(toml || "").split("\n")) {
    const line = raw.replace(/\s+#.*$/, "").trim();
    if (!line || line.startsWith("#")) continue;
    const h = line.match(/^\[\s*([^\]]+?)\s*\]$/);
    if (h) {
      table = h[1].replace(/\s+/g, "");
      continue;
    }
    const kv = line.match(/^([A-Za-z0-9_-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|(true|false))\s*$/);
    if (!kv) continue;
    const key = kv[1];
    const str = (_a = kv[2]) != null ? _a : kv[3];
    const bool = kv[4];
    if (table === "theme") {
      if (key === "auto_switch" && bool) out.autoSwitch = bool === "true";
      else if (str !== void 0 && NAME.test(str)) {
        if (key === "name") out.name = str;
        else if (key === "dark_name") out.darkName = str;
        else if (key === "light_name") out.lightName = str;
      }
      continue;
    }
    const target = table === "theme.custom" ? out.custom : table === "theme.custom.light" ? out.customLight : table === "theme.custom.dark" ? out.customDark : null;
    if (target && str !== void 0 && /^[a-z_]{1,32}$/.test(key) && (COLOR.test(str) || str === "reset")) target[key] = str;
  }
  return out;
}
async function readHerdrTheme() {
  try {
    return parseHerdrTheme(await fs.promises.readFile(path.join(HOME, ".config/herdr/config.toml"), "utf8"));
  } catch {
    return null;
  }
}

const config_get = defineApi(async () => ({
  hostLabel: localMachineLabel(),
  kinds: await installedAgentKinds(localMachine),
  home: HOME,
  os: localMachine.os,
  dirs: await recentDirs(),
  // Several machines: each with its home folder and recent folders.
  machines: await machineConfigs(),
  push: { enabled: pushReady(), key: vapidPublicKey(), devices: (await readSubs()).length },
  // Herdr theme (read-only), for "Follow Herdr".
  herdrTheme: await readHerdrTheme(),
  openNetwork: openNetworkMode()
}));

export { config_get as default };
//# sourceMappingURL=config.get.mjs.map

import { a as defineApi, P as PANE_RE, H as HerdrError, f as findPane, h as herdr, bu as settingsTabs, bv as tabsOfRow, bF as settingsFocus, X as sleep, g as choicesCache } from '../../nitro/nitro.mjs';
import { a as activeTab } from '../../_/settingstabs.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const switching = /* @__PURE__ */ new Set();
const settingsTab_post = defineApi(async (_event, b) => {
  var _a;
  const pane = String(b.pane_id || "");
  const target = String(b.target || "");
  if (!PANE_RE.test(pane)) throw new HerdrError("bad_pane", "Invalid pane");
  if (((_a = findPane(pane)) == null ? void 0 : _a.agent) !== "claude") throw new HerdrError("stale", "Settings are no longer open.");
  if (switching.has(pane)) throw new HerdrError("busy", "Settings tab change already in progress.");
  const read = async () => {
    var _a2;
    const r = await herdr("pane.read", { pane_id: pane, source: "visible", format: "ansi" }, 4e3);
    const ansi = String(((_a2 = r.read) == null ? void 0 : _a2.text) || "");
    const text = ansi.replace(/\x1b\[[\d;]*m|\r/g, "");
    const tabs = settingsTabs(text);
    const row = ansi.split("\n").find((l) => tabsOfRow(l.replace(/\x1b\[[\d;]*m|\r/g, "")));
    const tab = row && activeTab(row);
    if (!tabs || !tab || !tabs.includes(tab) || !tabs.includes(target)) throw new HerdrError("stale", "Settings have changed.");
    return { text, tabs, tab, ansi };
  };
  switching.add(pane);
  try {
    let screen = await read();
    for (let step = 0; screen.tab !== target; step++) {
      if (step >= screen.tabs.length) throw new HerdrError("stale", "Could not switch settings tabs. Open the terminal and try again.");
      for (let up = 0; screen.tab === "Config" && settingsFocus(screen.text) !== "tabs"; up++) {
        if (up >= 100 || settingsFocus(screen.text) === null) throw new HerdrError("stale", "Use the terminal to focus the settings tabs.");
        const before = screen;
        await herdr("pane.send_input", { pane_id: pane, keys: ["up"] });
        for (let attempt = 0; attempt < 15; attempt++) {
          await sleep(100);
          screen = await read();
          if (screen.ansi !== before.ansi) break;
        }
        if (screen.tab !== before.tab) throw new HerdrError("stale", "Settings have changed.");
        if (screen.ansi === before.ansi) throw new HerdrError("stale", "Use the terminal to focus the settings tabs.");
      }
      if (screen.tab === target) break;
      const direction = screen.tabs.indexOf(target) > screen.tabs.indexOf(screen.tab) ? 1 : -1;
      const next = screen.tabs[screen.tabs.indexOf(screen.tab) + direction];
      const previous = screen.tab;
      await herdr("pane.send_input", { pane_id: pane, keys: [direction > 0 ? "right" : "left"] });
      for (let attempt = 0; attempt < 15; attempt++) {
        await sleep(100);
        screen = await read();
        if (screen.tab !== previous) break;
      }
      if (screen.tab !== next) throw new HerdrError("stale", "Could not switch settings tabs. Open the terminal and try again.");
    }
    return { ok: true, tab: screen.tab };
  } finally {
    choicesCache.delete(pane);
    switching.delete(pane);
  }
});

export { settingsTab_post as default };
//# sourceMappingURL=settings-tab.post.mjs.map

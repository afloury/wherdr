import { a as defineApi, i as getQuery, P as PANE_RE, H as HerdrError, f as findPane } from '../../nitro/nitro.mjs';
import { r as restartPlanFor } from '../../_/restart.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const restart_get = defineApi(async (event) => {
  const pane = String(getQuery(event).pane || "");
  if (!PANE_RE.test(pane)) throw new HerdrError("bad_pane", "Invalid pane");
  const p = findPane(pane);
  if (!p || !p.agent) throw new HerdrError("bad_pane", "agent not found");
  const plan = await restartPlanFor(p);
  return { mode: plan.mode, kept: plan.kept, dropped: plan.dropped, unknownArgs: plan.unknownArgs };
});

export { restart_get as default };
//# sourceMappingURL=restart.get.mjs.map

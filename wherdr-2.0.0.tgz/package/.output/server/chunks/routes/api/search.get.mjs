import { a as defineApi, i as getQuery, a$ as getState, by as hasTranscript, q as machineOfPane, bz as SEARCH_DEADLINE_MS, bA as SEARCH_MAX_RESULTS, bB as spaceTitle } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const search_get = defineApi(async (event) => {
  const query = String(getQuery(event).q || "").trim().slice(0, 100);
  if (query.length < 2) return { hits: [], limited: false };
  const panes = getState().panes.filter((p) => {
    var _a;
    return hasTranscript(p.agent) && (!machineOfPane(p.id) || ((_a = machineOfPane(p.id)) == null ? void 0 : _a.status) === "online");
  });
  const deadline = Date.now() + SEARCH_DEADLINE_MS;
  const hits = [];
  let limited = false;
  let next = 0;
  async function worker() {
    while (next < panes.length && hits.length < SEARCH_MAX_RESULTS && Date.now() < deadline) {
      const p = panes[next++];
      const machine = machineOfPane(p.id);
      if (!machine) continue;
      try {
        let timer;
        const result = await Promise.race([
          machine.transcripts.search(p, query, deadline),
          new Promise((resolve) => {
            timer = setTimeout(() => resolve(null), Math.max(0, deadline - Date.now()));
          })
        ]).finally(() => clearTimeout(timer));
        if (!result) {
          limited = true;
          break;
        }
        limited || (limited = result.limited);
        for (const hit of result.hits) {
          if (hits.length >= SEARCH_MAX_RESULTS) {
            limited = true;
            break;
          }
          const title = spaceTitle(p, getState().workspaces.find((w) => w.id === p.workspace));
          hits.push({ ...hit, pane: p.id, agent: result.kind || p.agent, title });
        }
      } catch {
        limited = true;
      }
    }
  }
  await Promise.all([worker(), worker(), worker()]);
  if (next < panes.length) limited = true;
  hits.sort((a, b) => Date.parse(b.ts || "") - Date.parse(a.ts || ""));
  return { hits, limited };
});

export { search_get as default };
//# sourceMappingURL=search.get.mjs.map

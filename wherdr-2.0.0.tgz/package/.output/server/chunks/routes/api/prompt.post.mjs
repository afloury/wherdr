import { a as defineApi, P as PANE_RE, b4 as promptOnce, H as HerdrError, b5 as closeTrailingMention, az as isSlashCommand, b6 as keepPastes, O as restarting, aA as addQueued, p as poll, M as withPaneLock, f as findPane, ar as closePanel, aa as log, b7 as hasHeld, b8 as INPUT_STATES, h as herdr, b9 as inputVisible, ba as shouldHold, bb as inTurn, bc as sendPrompt, bd as agentPrompt, be as isBusyError, bf as HOLD_AGENTS, bg as pendingPrompts, e as watchScreen } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const prompt_post = defineApi(async (event, b) => {
  if (typeof b.client_id === "string" && /^w-[a-z0-9]{1,32}$/.test(b.client_id) && PANE_RE.test(b.pane_id || "")) {
    return promptOnce(b.pane_id, b.client_id, String(b.text || ""), async () => await submitPrompt(event, b));
  }
  return submitPrompt(event, b);
});
const submitPrompt = async (event, b) => {
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  const text = closeTrailingMention(String(b.text || ""));
  if (!text.trim()) throw new HerdrError("empty", "Empty message");
  const id = typeof b.client_id === "string" ? b.client_id : void 0;
  if (!isSlashCommand(text)) keepPastes(text, b.pastes);
  if (restarting(b.pane_id) && !isSlashCommand(text)) {
    const q2 = addQueued(b.pane_id, text, { held: true, id });
    setTimeout(poll, 50);
    return { ok: true, queued: q2 };
  }
  const held = await withPaneLock(b.pane_id, async () => {
    const now = findPane(b.pane_id);
    if (!(now == null ? void 0 : now.stopped) && !(now == null ? void 0 : now.leaving)) return null;
    if (isSlashCommand(text)) throw new HerdrError("stale", now.stopped ? "Restart Codex before sending a command." : "Codex just stopped. Try again in a few seconds.");
    const q2 = addQueued(b.pane_id, text, { held: true, id });
    setTimeout(poll, 50);
    return q2;
  });
  if (held) return { ok: true, queued: held };
  if (await withPaneLock(b.pane_id, () => {
    var _a;
    return ((_a = findPane(b.pane_id)) == null ? void 0 : _a.stopped) ? Promise.resolve(false) : closePanel(b.pane_id).catch(() => false);
  })) log(`panel closed before sending on ${b.pane_id}`);
  const p = findPane(b.pane_id);
  if (p && p.agent && restarting(p.id) && !isSlashCommand(text)) {
    const q2 = addQueued(b.pane_id, text, { held: true, id });
    log(`prompt ${b.pane_id}: restart in progress, message held`);
    setTimeout(poll, 50);
    return { ok: true, queued: q2 };
  }
  if (p && !isSlashCommand(text)) {
    const earlier = hasHeld(b.pane_id);
    const input = earlier || !INPUT_STATES.has(p.status || "") ? true : await herdr("pane.read", { pane_id: b.pane_id, source: "detection" }, 4e3).then((r) => inputVisible(r.read && r.read.text), () => true);
    if (shouldHold(p.agent, p.status, input, earlier)) {
      const q2 = addQueued(b.pane_id, text, { held: true, id, turn: inTurn(b.pane_id) });
      log(`prompt ${b.pane_id}: input field hidden, message held`);
      setTimeout(poll, 50);
      return { ok: true, queued: q2 };
    }
  }
  const typedAt = Date.now();
  try {
    if (p) await sendPrompt(p, text);
    else await agentPrompt(b.pane_id, text);
  } catch (e) {
    const typed = e.typed ? typedAt : void 0;
    if (isBusyError(e) && !e.typed && !isSlashCommand(text)) {
      const q2 = addQueued(b.pane_id, text, { held: true, busy: e.code === "input_busy", id, typedAt: typed, turn: inTurn(b.pane_id) });
      log(`prompt ${b.pane_id}: input field not free, message held`);
      setTimeout(poll, 50);
      return { ok: true, queued: q2 };
    }
    if (e instanceof HerdrError && ["not_shown", "not_submitted", "clear_failed", "input_contended", "bash_mode", "no_input", "input_busy"].includes(e.code) && !isSlashCommand(text)) {
      const q2 = addQueued(b.pane_id, text, { failed: true, id, typedAt: typed });
      log(`prompt ${b.pane_id}: ${e.message}, message kept as not sent`);
      setTimeout(poll, 50);
      return { ok: true, queued: q2 };
    }
    if (e instanceof HerdrError && e.code === "agent_blocked" && p && p.agent && HOLD_AGENTS.has(p.agent) && !isSlashCommand(text)) {
      const q2 = addQueued(b.pane_id, text, { held: true, id });
      log(`prompt ${b.pane_id}: agent blocked, message held`);
      setTimeout(poll, 50);
      return { ok: true, queued: q2 };
    }
    if (!(e instanceof HerdrError) || e.code !== "agent_not_ready" || isSlashCommand(text) || pendingPrompts.has(b.pane_id)) throw e;
    pendingPrompts.set(b.pane_id, { text, at: Date.now() });
    log(`prompt ${b.pane_id}: agent not ready for Herdr yet, queued`);
  }
  if (isSlashCommand(text)) {
    watchScreen(b.pane_id);
    setTimeout(poll, 1500);
    return { ok: true };
  }
  const q = addQueued(b.pane_id, text, { id, typedAt });
  setTimeout(poll, 50);
  return { ok: true, queued: q };
};

export { prompt_post as default };
//# sourceMappingURL=prompt.post.mjs.map

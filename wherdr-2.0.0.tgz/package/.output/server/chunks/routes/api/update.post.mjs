import { a as defineApi } from '../../nitro/nitro.mjs';
import { s as startUpdate } from '../../_/selfupdate.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';
import '../../_/package.mjs';
import '../../_/updates.mjs';

const update_post = defineApi(async (_event, body) => ({ job: await startUpdate(body.version) }));

export { update_post as default };
//# sourceMappingURL=update.post.mjs.map

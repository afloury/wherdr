import { a as defineApi, aj as readSubs, bj as writeSubs } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const unsubscribe_post = defineApi(async (event, b) => {
  const subs = (await readSubs()).filter((s) => s.endpoint !== (b && b.endpoint));
  await writeSubs(subs);
  return { ok: true, devices: subs.length };
});

export { unsubscribe_post as default };
//# sourceMappingURL=unsubscribe.post.mjs.map

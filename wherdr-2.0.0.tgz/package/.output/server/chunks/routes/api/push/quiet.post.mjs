import { a as defineApi, bh as parseQuiet, H as HerdrError, bi as writeGlobalQuiet, aj as readSubs, bj as writeSubs, aa as log, bk as quietActive, bl as readGlobalQuiet } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const quiet_post = defineApi(async (event, b) => {
  var _a;
  const endpoint = typeof b.endpoint === "string" ? b.endpoint : "";
  if (b.scope !== void 0) {
    const quiet = parseQuiet(b.on, b.until);
    if (quiet === void 0 || b.scope !== "device" && b.scope !== "all") throw new HerdrError("bad_quiet", "Invalid quiet setting");
    if (b.scope === "all") await writeGlobalQuiet(quiet);
    else {
      const subs = await readSubs();
      const sub = subs.find((s) => s.endpoint === endpoint);
      if (!sub) throw new HerdrError("no_sub", "Notifications are not enabled on this device");
      if (quiet) sub.quiet = quiet;
      else delete sub.quiet;
      await writeSubs(subs);
    }
    log(`push: quiet ${b.scope === "all" ? "all devices" : "one device"} ${quiet ? quiet.until ? `until ${new Date(quiet.until).toISOString()}` : "until turned back on" : "off"}`);
  }
  const device = endpoint ? (_a = (await readSubs()).find((s) => s.endpoint === endpoint)) == null ? void 0 : _a.quiet : void 0;
  return { global: await readGlobalQuiet(), device: device && quietActive(device) ? device : null };
});

export { quiet_post as default };
//# sourceMappingURL=quiet.post.mjs.map

import { a as defineApi, al as pushReady, H as HerdrError, bm as validPushSubscription, aj as readSubs, bn as replaceSubscription, bk as quietActive, bj as writeSubs, aa as log } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const subscribe_post = defineApi(async (event, b) => {
  if (!pushReady()) throw new HerdrError("push_off", "Web Push is not configured");
  if (!validPushSubscription(b)) throw new HerdrError("bad_sub", "Invalid subscription");
  const all = await readSubs();
  const sessions = {};
  if (b.sessions && typeof b.sessions === "object" && !Array.isArray(b.sessions)) {
    for (const [key, name] of Object.entries(b.sessions)) {
      if ((key === "" || /^[0-9a-f]{4,32}$/.test(key)) && typeof name === "string" && /^[\w.-]{1,64}$/.test(name)) sessions[key] = name;
    }
  }
  const subs = replaceSubscription(all, {
    endpoint: b.endpoint,
    keys: { p256dh: b.keys.p256dh, auth: b.keys.auth },
    lang: b.lang === "fr" ? "fr" : "en",
    sessions,
    addedAt: (/* @__PURE__ */ new Date()).toISOString()
  }, b.previous, quietActive);
  await writeSubs(subs);
  log(`push: subscription saved (${subs.length} device(s))`);
  return { ok: true, devices: subs.length };
});

export { subscribe_post as default };
//# sourceMappingURL=subscribe.post.mjs.map

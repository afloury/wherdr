import { a as defineApi, bo as pushSend } from '../../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const test_post = defineApi(async () => ({
  sent: await pushSend({ title: "wherdr", body: "Notifications are working \u2713", bodyFr: "Les notifications fonctionnent \u2713", tag: "test", url: "/" }, void 0, true)
}));

export { test_post as default };
//# sourceMappingURL=test.post.mjs.map

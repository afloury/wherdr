import { a as defineApi, H as HerdrError } from '../../../nitro/nitro.mjs';
import { r as removeWorktree } from '../../../_/worktrees.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const remove_post = defineApi(async (event, b) => {
  if (typeof b.path !== "string" || !b.path.startsWith("/")) throw new HerdrError("bad_path", "Invalid path");
  return removeWorktree(String(b.machine || ""), b.path, b.force === true);
});

export { remove_post as default };
//# sourceMappingURL=remove.post.mjs.map

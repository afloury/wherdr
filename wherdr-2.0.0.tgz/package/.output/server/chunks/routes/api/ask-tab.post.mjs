import { a as defineApi, P as PANE_RE, H as HerdrError, h as herdr, b as screenChoices, f as findPane, w as withOmpTab, e as watchScreen, g as choicesCache, p as poll } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const askTab_post = defineApi(async (event, b) => {
  var _a;
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  const pane = b.pane_id;
  const r = await herdr("pane.read", { pane_id: pane, source: "detection" }, 4e3);
  const shown = screenChoices(r.read && r.read.text, (_a = findPane(pane)) == null ? void 0 : _a.agent);
  const c = shown && !shown.typing ? await withOmpTab(pane, shown) : null;
  const i = Number(b.index);
  if (!c || !c.tabs || c.tab === void 0 || c.tabs[i] !== b.label) {
    throw new HerdrError("stale", "The screen has changed \u2014 check the current screen.");
  }
  const d = i - c.tab;
  if (d) await herdr("pane.send_input", { pane_id: pane, keys: Array.from({ length: Math.abs(d) }, () => d > 0 ? "right" : "left") });
  watchScreen(pane, 3e4);
  for (const ms of [50, 150, 400]) setTimeout(() => {
    choicesCache.delete(pane);
    poll();
  }, ms);
  return { ok: true };
});

export { askTab_post as default };
//# sourceMappingURL=ask-tab.post.mjs.map

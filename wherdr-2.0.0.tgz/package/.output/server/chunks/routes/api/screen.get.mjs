import { a as defineApi, i as getQuery, P as PANE_RE, H as HerdrError, h as herdr, bu as settingsTabs, bv as tabsOfRow, f as findPane, bw as classifyScreen, bs as parseWaitScreen, bx as parseMenu, b as screenChoices } from '../../nitro/nitro.mjs';
import { a as activeTab } from '../../_/settingstabs.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const screen_get = defineApi(async (event) => {
  const pane = String(getQuery(event).pane || "");
  if (!PANE_RE.test(pane)) throw new HerdrError("bad_pane", "Invalid pane");
  const r = await herdr("pane.read", { pane_id: pane, source: "visible" }, 4e3);
  const text = r.read && r.read.text || "";
  const tabs = settingsTabs(text);
  let tab = null;
  if (tabs) {
    const a = await herdr("pane.read", { pane_id: pane, source: "visible", format: "ansi" }, 4e3).catch(() => null);
    const line = String(a && a.read && a.read.text || "").split("\n").find((l) => tabsOfRow(l.replace(/\x1b\[[\d;]*m|\r/g, "")));
    const hit = line ? activeTab(line) : null;
    tab = hit && tabs.includes(hit) ? hit : null;
  }
  const p = findPane(pane);
  const interaction = classifyScreen({ text, agent: p == null ? void 0 : p.agent, status: p == null ? void 0 : p.status, choices: screenChoices(text, p == null ? void 0 : p.agent), settings: Boolean(tabs), menu: parseMenu(text), screen: parseWaitScreen(text) });
  return { text, tabs, tab, interaction };
});

export { screen_get as default };
//# sourceMappingURL=screen.get.mjs.map

import { a as defineApi, P as PANE_RE, H as HerdrError, aM as readMenu, aN as findEntry, aO as menuIdentity, aP as searchKeys, X as sleep, aQ as stepToward, aR as clickMovesOnly, e as watchScreen, y as transcripts, p as poll, h as herdr } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const STALE = "The menu changed in the meantime \u2014 check the current screen.";
const at = (m) => m && m.cursor !== null ? `${m.cursor}:${m.items[m.cursor].label}` : null;
const send = (pane, keys) => herdr("pane.send_input", { pane_id: pane, keys });
const menu_post = defineApi(async (event, b) => {
  var _a;
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  const pane = b.pane_id;
  let menu = await readMenu(pane);
  if (!menu) throw new HerdrError("stale", STALE);
  const targetEntry = b.op === "select" ? menu.items[findEntry(menu, Number(b.index), String(b.label || ""))] : void 0;
  if (!b.identity || menuIdentity(menu, targetEntry) !== b.identity) throw new HerdrError("stale", STALE);
  if (b.op === "key") {
    const a = menu.actions.find((x) => x.key === b.key && x.label === b.label);
    if (!a) throw new HerdrError("stale", STALE);
    await send(pane, [a.key]);
  } else if (b.op === "search") {
    const text = String((_a = b.text) != null ? _a : "").replace(/[\r\n\t]/g, " ").slice(0, 100);
    if (menu.search === null) throw new HerdrError("stale", STALE);
    const keys = searchKeys(menu.search, text);
    for (const k of keys) {
      await send(pane, [k]);
      await sleep(25);
    }
  } else if (b.op === "select") {
    const label = String(b.label || "");
    let target = findEntry(menu, Number(b.index), label);
    for (let n = 0; n < 60; n++) {
      if (target < 0) throw new HerdrError("stale", STALE);
      const step = stepToward(menu, target);
      if (!step) throw new HerdrError("stale", "This entry can\u2019t be chosen here \u2014 check the terminal.");
      if (step === "enter" && (b.move || clickMovesOnly(menu))) break;
      await send(pane, [step]);
      if (step === "enter") break;
      const before = at(menu);
      await sleep(120);
      menu = await readMenu(pane);
      if (at(menu) === before) {
        await sleep(250);
        menu = await readMenu(pane);
      }
      if (!menu || at(menu) === before) throw new HerdrError("stale", "The cursor doesn\u2019t move \u2014 finish in the terminal.");
      target = findEntry(menu, -1, label);
      if (target < 0 || menuIdentity(menu, menu.items[target]) !== b.identity) throw new HerdrError("stale", STALE);
    }
  } else throw new HerdrError("bad_request", "Invalid operation");
  watchScreen(pane, 3e4);
  if (b.op === "select") for (const ms of [800, 2500, 6e3]) setTimeout(() => transcripts.forget(pane), ms);
  setTimeout(poll, 300);
  return { ok: true };
});

export { menu_post as default };
//# sourceMappingURL=menu.post.mjs.map

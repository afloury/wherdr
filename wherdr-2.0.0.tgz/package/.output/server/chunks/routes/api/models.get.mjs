import { a as defineApi, i as getQuery, P as PANE_RE, H as HerdrError, aT as listModels } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const models_get = defineApi(async (event) => {
  const q = getQuery(event);
  const pane = String(q.pane || "");
  if (!PANE_RE.test(pane)) throw new HerdrError("bad_pane", "Invalid pane");
  return listModels(pane, q.refresh === "1");
});

export { models_get as default };
//# sourceMappingURL=models.get.mjs.map

import { H as HerdrError, br as PANE_RE, f as findPane, $ as getMachine, a_ as splitId, t as fmt, aa as log, a as defineApi } from '../../nitro/nitro.mjs';
import { execFile } from 'node:child_process';
import { r as resolveAgentPath, a as runnablePath } from '../../_/filePaths.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const REVEAL_CHECKS = `p=$2
[ -e "$p" ] || exit 3
if command -v realpath >/dev/null 2>&1; then
  r=$(realpath "$p" 2>/dev/null) || exit 3
  h=$(realpath "$HOME" 2>/dev/null) || exit 4
elif [ -d "$p" ]; then
  r=$(cd -P "$p" 2>/dev/null && pwd -P) || exit 3
  h=$(cd -P "$HOME" 2>/dev/null && pwd -P) || exit 4
else
  d=$(cd -P "$(dirname "$p")" 2>/dev/null && pwd -P) || exit 3
  r="$d/$(basename "$p")"
  [ -L "$r" ] && [ "$1" = open ] && exit 4
  h=$(cd -P "$HOME" 2>/dev/null && pwd -P) || exit 4
fi
case "$r/" in "$h"/*) ;; *) exit 4 ;; esac
[ "$(uname -s)" = Darwin ] || exit 5
if [ "$1" = open ]; then
  case "$r" in *.app|*.app/*|*.command|*.tool|*.terminal|*.pkg|*.mpkg|*.workflow|*.scpt|*.applescript|*.jar|*.webloc|*.inetloc|*.fileloc|*.dmg) exit 7 ;; esac
  if [ -f "$r" ] && [ -x "$r" ]; then exit 7; fi
  # A folder opens in the configured editor (WH_OPEN_EDITOR, or the first line
  # of ~/.local/share/wherdr/editor \u2014 an app name for open -a); plain open
  # would give the file manager. Files: the LaunchServices default app.
  ed=\${WH_OPEN_EDITOR:-}
  if [ -z "$ed" ] && [ -f "$HOME/.local/share/wherdr/editor" ]; then
    ed=$(head -n1 "$HOME/.local/share/wherdr/editor" | tr -d '[:space:]')
  fi
  if [ -d "$r" ] && [ -n "$ed" ]; then
    open -a "$ed" "$r" || exit 6
  else
    open "$r" || exit 6
  fi
else
  open -R "$r" || exit 6
fi
echo "$r"`;
const REVEAL_SCRIPT = REVEAL_CHECKS;
const revealArgs = (mode, absPath) => [mode, absPath];
const isMac = (m) => m.os === "Darwin";
function runLocal(script, args) {
  const { promise, resolve } = Promise.withResolvers();
  execFile("/bin/sh", ["-c", script, "sh", ...args], { timeout: 15e3, encoding: "buffer" }, (err, stdout, stderr) => {
    const raw = err ? typeof err === "object" && err !== null && "code" in err ? err.code : void 0 : 0;
    resolve({ code: typeof raw === "number" ? raw : err ? 1 : 0, stdout, stderr: String(stderr || "") });
  });
  return promise;
}
function revealError(code, p, m, stderr = "") {
  switch (code) {
    case 3:
      return new HerdrError("not_found", fmt("Not found on {machine}: {path}", { machine: m.label, path: p }));
    case 4:
      return new HerdrError("outside_home", "Only files in your home folder can be shown");
    case 5:
      return new HerdrError("not_mac", fmt("{machine} is not a Mac", { machine: m.label }));
    case 7:
      return new HerdrError("runnable", "Apps and scripts are not opened from wherdr: use Reveal in Finder");
    default:
      return new HerdrError("open_failed", fmt("Could not open on {machine}: {reason}", { machine: m.label, reason: stderr.trim().split("\n").pop() || `code ${code}` }));
  }
}
async function revealPath(body) {
  const paneId = String(body.pane_id || "");
  const written = String(body.path || "");
  const mode = body.mode === "open" ? "open" : body.mode === "reveal" ? "reveal" : null;
  if (!mode) throw new HerdrError("bad_mode", "Invalid action");
  if (!PANE_RE.test(paneId)) throw new HerdrError("bad_pane", "Invalid pane");
  const pane = findPane(paneId);
  if (!pane) throw new HerdrError("bad_pane", "Pane not found");
  if (!written || written.length > 1024) throw new HerdrError("bad_path", "Invalid path");
  const m = getMachine(splitId(paneId).machine);
  if (!m) throw new HerdrError("bad_machine", "unknown machine");
  if (!m.local && (m.status !== "online" || !m.home)) throw new HerdrError("unreachable", fmt("{machine} is unreachable", { machine: m.label }));
  if (!isMac(m)) throw new HerdrError("not_mac", fmt("{machine} is not a Mac", { machine: m.label }));
  const abs = resolveAgentPath(written, pane.cwd, m.home);
  if (!abs) throw new HerdrError("outside_home", "Only files in your home folder can be shown");
  if (mode === "open" && runnablePath(abs)) throw revealError(7, abs, m);
  const args = revealArgs(mode, abs);
  const r = m.local ? await runLocal(REVEAL_SCRIPT, args) : await m.exec(REVEAL_SCRIPT, args, { timeoutMs: 15e3 });
  log(`reveal: ${mode} on ${m.label} for ${paneId}: ${r.code === 0 ? "ok" : `refused (code ${r.code})`}`);
  if (r.code !== 0) throw revealError(r.code, abs, m, r.stderr);
  return { ok: true, mode, path: r.stdout.toString("utf8").trim() || abs, machine: m.label };
}

const reveal_post = defineApi((event, b) => revealPath(b));

export { reveal_post as default };
//# sourceMappingURL=reveal.post.mjs.map

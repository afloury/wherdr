import { a as defineApi, i as getQuery, f as findPane, H as HerdrError, m as machineFor } from '../../../nitro/nitro.mjs';
import { f as readWrittenPreview, g as readFilePreview } from '../../../_/files.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';
import '../../../_/filePaths.mjs';
import '../../../_/changes.mjs';

const read_get = defineApi(async (event) => {
  const q = getQuery(event);
  const p = findPane(String(q.pane || ""));
  if (!p) throw new HerdrError("bad_pane", "Pane not found");
  if (q.from === "chat") return readWrittenPreview(machineFor(p.machine), p.cwd, q.path);
  if (!p.cwd) throw new HerdrError("bad_cwd", "This agent\u2019s folder is unknown");
  return readFilePreview(machineFor(p.machine), p.cwd, q.path);
});

export { read_get as default };
//# sourceMappingURL=read.get.mjs.map

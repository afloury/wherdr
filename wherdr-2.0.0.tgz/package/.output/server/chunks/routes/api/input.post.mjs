import { a as defineApi, P as PANE_RE, H as HerdrError, M as withPaneLock, f as findPane, y as transcripts, h as herdr, b as screenChoices, V as usesTerminalException, az as isSlashCommand, aA as addQueued, p as poll, g as choicesCache } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const input_post = defineApi(async (event, b) => {
  if (!PANE_RE.test(b.pane_id || "")) throw new HerdrError("bad_pane", "Invalid pane");
  const held = await withPaneLock(b.pane_id, async () => {
    var _a;
    try {
      const now = findPane(b.pane_id);
      if (b.native) {
        const asked = (now == null ? void 0 : now.agent) === "claude" ? await transcripts.pendingClaudeQuestions(now).catch(() => []) : [];
        const r = await herdr("pane.read", { pane_id: b.pane_id, source: "detection" }, 4e3);
        const text = (_a = r.read) == null ? void 0 : _a.text;
        const choices = screenChoices(text, now == null ? void 0 : now.agent, asked);
        if ((now == null ? void 0 : now.stopped) || (now == null ? void 0 : now.leaving) || !b.identity || (choices == null ? void 0 : choices.identity) !== b.identity || usesTerminalException({ text: String(text || ""), agent: now == null ? void 0 : now.agent, status: now == null ? void 0 : now.status })) {
          throw new HerdrError("stale", "The question has changed \u2014 check the current screen.");
        }
      }
      if ((now == null ? void 0 : now.stopped) || (now == null ? void 0 : now.leaving)) {
        if (typeof b.text !== "string" || !b.text.trim() || isSlashCommand(b.text) || !Array.isArray(b.keys) || b.keys.length !== 1 || b.keys[0] !== "enter") {
          throw new HerdrError("stale", now.stopped ? "Restart Codex before sending a command." : "Codex just stopped. Try again in a few seconds.");
        }
        const q = addQueued(b.pane_id, b.text, { held: true });
        setTimeout(poll, 50);
        return q;
      }
      if (typeof b.text === "string" && b.text) await herdr("pane.send_input", { pane_id: b.pane_id, text: b.text });
      if (Array.isArray(b.keys) && b.keys.length) await herdr("pane.send_input", { pane_id: b.pane_id, keys: b.keys.map(String) });
    } finally {
      if (b.native) {
        choicesCache.delete(b.pane_id);
        setTimeout(poll, 0);
      }
    }
  });
  if (held) return { ok: true, queued: held };
  const p = findPane(b.pane_id);
  if (p && p.agent && typeof b.text === "string" && b.text.trim() && !isSlashCommand(b.text)) {
    const q = addQueued(b.pane_id, b.text);
    setTimeout(poll, 50);
    return { ok: true, queued: q };
  }
  return { ok: true };
});

export { input_post as default };
//# sourceMappingURL=input.post.mjs.map

import { cg as defineWebSocketHandler, cr as openTerm } from '../../nitro/nitro.mjs';
import { u as unwatchPeer, m as messageText, w as watchPeer, c as checkUpgrade, i as isOpen } from '../../_/ws.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const sessions = /* @__PURE__ */ new Map();
const term = defineWebSocketHandler({
  upgrade: (request) => checkUpgrade(request),
  open(peer) {
    var _a;
    watchPeer(peer);
    const url = new URL(((_a = peer.request) == null ? void 0 : _a.url) || "/", "http://x");
    const sess = openTerm({
      send: (d) => peer.send(d),
      close: (code, reason) => peer.close(code, reason),
      isOpen: () => isOpen(peer)
    }, url);
    if (sess) sessions.set(peer.id, sess);
  },
  message(peer, message) {
    var _a;
    const raw = messageText(message);
    if (raw) (_a = sessions.get(peer.id)) == null ? void 0 : _a.onMessage(raw);
  },
  close(peer, details) {
    unwatchPeer(peer);
    const s = sessions.get(peer.id);
    sessions.delete(peer.id);
    s == null ? void 0 : s.onClose((details == null ? void 0 : details.code) === 1e3);
  }
});

export { term as default };
//# sourceMappingURL=term.mjs.map

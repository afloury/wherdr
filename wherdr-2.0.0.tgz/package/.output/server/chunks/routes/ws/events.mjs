import { cg as defineWebSocketHandler, ch as eventClients, P as PANE_RE, ci as notificationPresence, cj as getStateJson } from '../../nitro/nitro.mjs';
import { u as unwatchPeer, m as messageText, w as watchPeer, i as isOpen, c as checkUpgrade } from '../../_/ws.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const events = defineWebSocketHandler({
  upgrade: (request) => checkUpgrade(request),
  open(peer) {
    watchPeer(peer);
    eventClients.set(peer.id, { send: (d) => isOpen(peer) && peer.send(d), pane: null, visible: false });
    peer.send(getStateJson());
  },
  message(peer, message) {
    const raw = messageText(message);
    if (!raw) return;
    let m;
    try {
      m = JSON.parse(raw);
    } catch {
      return;
    }
    const c = eventClients.get(peer.id);
    if (c && m && m.type === "viewing") {
      c.pane = PANE_RE.test(m.pane || "") ? m.pane : null;
      c.visible = m.visible === true;
      notificationPresence.heartbeat(peer.id, c.pane, c.visible);
    }
  },
  close(peer) {
    unwatchPeer(peer);
    eventClients.delete(peer.id);
  }
});

export { events as default };
//# sourceMappingURL=events.mjs.map

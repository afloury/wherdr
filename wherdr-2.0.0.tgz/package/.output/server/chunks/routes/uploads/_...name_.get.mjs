import { d as defineEventHandler, ce as getRouterParam, cf as readUpload, s as sendError, I as sendImage } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:crypto';
import 'stream';
import 'events';
import 'http';
import 'crypto';
import 'buffer';
import 'zlib';
import 'https';
import 'net';
import 'tls';
import 'url';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:os';
import 'node:net';
import 'node:child_process';
import 'node:dns';
import 'node:util';
import 'web-push';
import 'node:string_decoder';
import 'node:fs/promises';
import 'node:readline';
import 'qrcode-terminal/vendor/QRCode/index.js';
import 'qrcode-terminal/vendor/QRCode/QRErrorCorrectLevel.js';
import 'node:url';
import '@simplewebauthn/server';

const ____name__get = defineEventHandler(async (event) => {
  try {
    const name = decodeURIComponent(getRouterParam(event, "name") || "");
    const img = await readUpload(name);
    if (!img) return sendError(event, 404, { error: "Image not found" });
    return sendImage(event, img);
  } catch {
    return sendError(event, 404, { error: "Image not found" });
  }
});

export { ____name__get as default };
//# sourceMappingURL=_...name_.get.mjs.map

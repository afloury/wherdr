import { H as HerdrError, a3 as paneForeground, a4 as codexMenuOpen, a5 as stopAgent, a6 as terminalUpdateLine, a7 as waitFor, a8 as terminalUpdateDone, a9 as startAgent, X as sleep, f as findPane, T as restarts, aa as log, M as withPaneLock, ab as RESTARTABLE, y as transcripts, ac as claudeFooterMode, ad as planRestart, h as herdr, p as poll } from '../nitro/nitro.mjs';
import crypto from 'node:crypto';

const TERM_UPDATE_MS = 10 * 6e4;
const READ_LINES = 400;
const readRecent = async (d, paneId) => {
  const r = await d.call("pane.read", { pane_id: paneId, source: "recent_unwrapped", lines: READ_LINES }, 4e3);
  return String(r && r.read && r.read.text || "");
};
async function checkTerminalUpdate(d, p) {
  if (p.agent !== "codex") throw new HerdrError("bad_pane", "agent not found");
  if (p.status === "working" || p.status === "blocked") throw new HerdrError("agent_busy", "Codex is working or waiting for an answer: update it once it is done");
  const fg = await paneForeground(d, p.id, "codex");
  if (!fg.agent) throw new HerdrError("update_no_agent", "Codex is not running in this pane");
  if (!fg.shell.pid) throw new HerdrError("update_no_shell", "Codex was not started from a shell: quitting it would close the pane");
  const r = await d.call("pane.read", { pane_id: p.id, source: "visible" }, 4e3);
  if (codexMenuOpen(r && r.read && r.read.text)) throw new HerdrError("update_menu", "Codex is showing a menu: answer it first");
}
async function updateInTerminal(d, p, plan, command) {
  const nonce = (d.nonce || (() => crypto.randomBytes(6).toString("hex")))();
  d.phase("stopping");
  await stopAgent(d, p);
  const fg = await paneForeground(d, p.id, "codex");
  const line = terminalUpdateLine(command, nonce, fg.shell.name);
  if (!line) throw new HerdrError("update_shell", `Unsupported shell (${fg.shell.name || "unknown"}): run the command yourself`);
  d.phase("updating");
  await d.call("pane.send_input", { pane_id: p.id, text: line });
  await d.sleep(300);
  await d.call("pane.send_input", { pane_id: p.id, keys: ["enter"] });
  const result = { end: null };
  await waitFor(d, TERM_UPDATE_MS, async () => Boolean(result.end = terminalUpdateDone(await readRecent(d, p.id), nonce)));
  const end = result.end;
  if (!end) throw new HerdrError("update_timeout", "The update did not finish in 10 minutes: see the terminal");
  if (end.code !== 0) throw new HerdrError("update_failed", `exit code ${end.code}${end.last ? ` \xB7 ${end.last}` : ""}`);
  await waitFor(d, 5e3, async () => (await paneForeground(d, p.id, "codex")).atShell);
  d.phase("starting");
  await startAgent(d, p, plan);
}

const defaultDeps = { call: (m, params, t) => herdr(m, params, t), sleep, now: Date.now };
async function restartPlanFor(p, d = defaultDeps) {
  var _a, _b, _c, _d;
  if (!p.agent || !RESTARTABLE.has(p.agent)) throw new HerdrError("restart_unsupported", "agent not supported");
  let argv = null;
  try {
    argv = (await paneForeground(d, p.id, p.agent)).argv;
  } catch {
    argv = null;
  }
  let session = null;
  try {
    session = ((_a = await transcripts.locate(p)) == null ? void 0 : _a.session) || null;
  } catch {
    session = null;
  }
  const current = {};
  if (p.agent === "claude") {
    current.effort = ((_b = p.model) == null ? void 0 : _b.effort) || null;
    if (p.status !== "blocked") {
      try {
        current.permissionMode = claudeFooterMode((_d = (_c = await d.call("pane.read", { pane_id: p.id, source: "visible" }, 4e3)) == null ? void 0 : _c.read) == null ? void 0 : _d.text);
      } catch {
      }
    }
  }
  return planRestart({ kind: p.agent, argv, session, hadSession: Boolean(p.agentSession), current });
}
const planning = /* @__PURE__ */ new Set();
async function restartAgent(paneId) {
  const p = findPane(paneId);
  if (p == null ? void 0 : p.stopped) throw new HerdrError("stale", "Use the restart buttons for this stopped agent.");
  if (!p || !p.agent) throw new HerdrError("bad_pane", "agent not found");
  const cur = restarts.get(paneId);
  if (planning.has(paneId) || cur && cur.phase !== "failed") throw new HerdrError("restart_busy", "restart already in progress");
  planning.add(paneId);
  let plan;
  try {
    plan = await restartPlanFor(p);
  } finally {
    planning.delete(paneId);
  }
  const snap = { id: p.id, agent: p.agent, status: p.status, name: p.name };
  const session = p.agentSession;
  restarts.set(paneId, { phase: "stopping", agent: p.agent, session, at: Date.now() });
  poll();
  void withPaneLock(paneId, async () => {
    let stopped = false;
    try {
      await stopAgent(defaultDeps, snap);
      stopped = true;
      restarts.set(paneId, { phase: "starting", agent: snap.agent, session, at: Date.now() });
      poll();
      await startAgent(defaultDeps, snap, plan);
      restarts.set(paneId, { phase: "starting", agent: snap.agent, session, at: Date.now(), started: true });
      log(`agent ${snap.agent} restarted (${plan.mode}) in ${paneId}`);
    } catch (e) {
      restarts.set(paneId, { phase: "failed", agent: snap.agent, session, at: Date.now(), stopped, error: e.message });
      log(`restart of ${paneId} failed: ${e.message}`);
    }
    poll();
  });
  return plan;
}
async function updateCodexInPane(paneId, command) {
  const p = findPane(paneId);
  if (!p || p.agent !== "codex") throw new HerdrError("bad_pane", "agent not found");
  const cur = restarts.get(paneId);
  if (planning.has(paneId) || cur && cur.phase !== "failed") throw new HerdrError("restart_busy", "restart already in progress");
  planning.add(paneId);
  let plan;
  try {
    await checkTerminalUpdate(defaultDeps, p);
    plan = await restartPlanFor(p);
  } finally {
    planning.delete(paneId);
  }
  const snap = { id: p.id, agent: p.agent, status: p.status, name: p.name };
  const session = p.agentSession;
  const set = (phase, more = {}) => {
    restarts.set(paneId, { phase, agent: "codex", session, at: Date.now(), update: command, ...more });
    poll();
  };
  set("stopping");
  log(`codex update in ${paneId}: ${command}`);
  let stopped = false;
  const done = withPaneLock(paneId, () => updateInTerminal({
    ...defaultDeps,
    phase: (ph) => {
      if (ph !== "stopping") stopped = true;
      set(ph);
    }
  }, snap, plan, command)).then(() => {
    set("starting", { started: true });
    log(`codex updated and restarted (${plan.mode}) in ${paneId}`);
  }, (e) => {
    set("failed", { stopped, error: e.message });
    log(`codex update in ${paneId} failed: ${e.message}`);
    throw e;
  });
  return { done };
}
function dismissRestart(paneId) {
  var _a;
  if (((_a = restarts.get(paneId)) == null ? void 0 : _a.phase) === "failed") restarts.delete(paneId);
  poll();
}

export { restartAgent as a, dismissRestart as d, restartPlanFor as r, updateCodexInPane as u };
//# sourceMappingURL=restart.mjs.map

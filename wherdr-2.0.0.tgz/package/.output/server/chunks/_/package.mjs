var name = "wherdr";
var version = "2.0.0";
var license = "MIT";
var type = "module";
var description = "Unofficial mobile web client (PWA) to drive the coding agents running in Herdr";
var keywords = [
	"herdr",
	"pwa",
	"claude-code",
	"codex",
	"coding-agents",
	"remote",
	"mobile"
];
var homepage = "https://wherdr.dev";
var repository = {
	type: "git",
	url: "git+https://github.com/afloury/wherdr.git"
};
var bugs = "https://github.com/afloury/wherdr/issues";
var bin = {
	wherdr: "bin/wherdr.mjs"
};
var files = [
	".output",
	"!.output/**/*.map",
	"bin",
	"skills/wherdr",
	"docs/*.md"
];
var engines = {
	node: ">=22"
};
var scripts = {
	dev: "nuxt dev",
	build: "nuxt build",
	"build:demo": "VITE_WHERDR_DEMO=1 nuxt generate",
	start: "HOST=${HOST:-127.0.0.1} PORT=${PORT:-7683} node .output/server/index.mjs",
	typecheck: "nuxt typecheck",
	test: "vitest run",
	"test:e2e": "playwright test",
	"shots:readme": "node tools/readme-shots/capture.mjs",
	"test:e2e:shots": "SHOTS=${SHOTS:-.shots} playwright test tests/e2e/question-reply.spec.ts --grep screenshot:",
	"test:e2e:stability": "playwright test menu-responsiveness codex-self-update quote-mode onboarding-tailnet --grep \"MCP arrow paints|a new Codex restarts|the former per-device values|a quoted question keeps|#/setup[?]step=security opens|a direct Security link\"",
	prepare: "nuxt prepare",
	prepack: "nuxt build && node scripts/pack-output.mjs",
	"check:docs": "node scripts/check-doc-links.mjs",
	"check:leaks": "node scripts/check-leaks.mjs",
	"hooks:install": "git config core.hooksPath .githooks",
	"test:affected": "node scripts/test-affected.mjs"
};
var dependencies = {
	"qrcode-terminal": "^0.12.0"
};
var devDependencies = {
	"@fontsource-variable/archivo": "^5.3.0",
	"@fontsource-variable/inter": "^5.3.0",
	"@fontsource-variable/jetbrains-mono": "^5.3.0",
	"@iconify-json/lucide": "^1.2.136",
	"@nuxt/test-utils": "^4.3.3",
	"@nuxt/ui": "^4.11.2",
	"@playwright/test": "^1.63.0",
	"@simplewebauthn/browser": "^13.3.0",
	"@simplewebauthn/server": "^13.3.3",
	"@types/node": "^22.0.0",
	"@types/web-push": "^3.6.4",
	"@vite-pwa/nuxt": "^1.1.1",
	"@vue/reactivity": "^3.5.43",
	"@vue/test-utils": "^2.5.1",
	"@xterm/addon-fit": "^0.10.0",
	"@xterm/addon-webgl": "^0.18.0",
	"@xterm/xterm": "^5.5.0",
	dompurify: "^3.4.16",
	"happy-dom": "^20.14.5",
	marked: "^15.0.12",
	nuxt: "^4.5.2",
	"pdfjs-dist": "5.4.624",
	tailwindcss: "^4.3.3",
	typescript: "~5.9.3",
	vitest: "^4.1.11",
	vue: "^3.5.0",
	"vue-router": "^4.5.0",
	"vue-tsc": "^3.0.0",
	"web-push": "^3.6.7"
};
const pkg = {
	name: name,
	version: version,
	license: license,
	type: type,
	description: description,
	keywords: keywords,
	homepage: homepage,
	repository: repository,
	bugs: bugs,
	bin: bin,
	files: files,
	engines: engines,
	scripts: scripts,
	dependencies: dependencies,
	devDependencies: devDependencies
};

export { pkg as p };
//# sourceMappingURL=package.mjs.map

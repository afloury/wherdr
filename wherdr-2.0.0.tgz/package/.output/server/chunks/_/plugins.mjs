import { m as machineFor, aZ as herdrOn, H as HerdrError, f as findPane, a_ as splitId, a$ as getState, aa as log, X as sleep } from '../nitro/nitro.mjs';

const PLUGIN_ID_RE = /^[A-Za-z0-9.:_-]{1,100}$/;
const ACTION_ID_RE = /^[A-Za-z0-9:_-]{1,100}$/;
function actionContext(pane, workspaces = []) {
  const context = { invocation_source: "wherdr" };
  if (!pane) return context;
  const local = (id) => id.includes("~") ? id.slice(id.indexOf("~") + 1) : id;
  const workspace = workspaces.find((w) => w.id === pane.workspace);
  return {
    ...context,
    focused_pane_id: local(pane.id),
    tab_id: local(pane.tab),
    workspace_id: local(pane.workspace),
    workspace_label: (workspace == null ? void 0 : workspace.label) || "",
    workspace_cwd: pane.cwd || "",
    focused_pane_cwd: pane.cwd || ""
  };
}
const AGENT_CONTEXTS = ["workspace", "tab", "pane"];
const READ_ONLY = /\b(list|lists|show|status|view|info|doctor|check|help|preview|inspect|lister|liste|voir|afficher|état|etat|vérifier|verifier|aide)\b/i;
function needsConfirm(a) {
  return !(READ_ONLY.test(a.id.replace(/[_:]/g, "-")) || READ_ONLY.test(a.title));
}
function shortLabel(title, pluginName) {
  const esc = pluginName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const rest = title.replace(new RegExp(`^${esc}\\s*[:\xB7\u2014\u2013-]\\s*`, "i"), "").trim();
  return rest ? rest[0].toUpperCase() + rest.slice(1) : title;
}
const isOwnPlugin = (id) => id === "wherdr" || id.endsWith(".wherdr");
function opensInHerdr(a) {
  if (a.placement === "popup" || a.placement === "overlay") return true;
  const cmd = Array.isArray(a.command) ? a.command.map(String).join(" ") : "";
  if (/\bplugin\s+pane\s+open\b/.test(cmd)) return true;
  return /(^|[-_:])popup($|[-_:])/i.test(String(a.action_id || ""));
}
function normalizeActions(actions, plugins = []) {
  const byId = new Map(plugins.filter((p) => p && p.plugin_id).map((p) => [p.plugin_id, p]));
  const out = [];
  for (const a of actions || []) {
    const plugin = String((a == null ? void 0 : a.plugin_id) || "");
    const id = String((a == null ? void 0 : a.action_id) || "");
    if (!PLUGIN_ID_RE.test(plugin) || !ACTION_ID_RE.test(id) || isOwnPlugin(plugin)) continue;
    const p = byId.get(plugin);
    if (p && p.enabled === false) continue;
    const ctx = (Array.isArray(a.contexts) ? a.contexts : []).map(String);
    const agent = ctx.some((c) => AGENT_CONTEXTS.includes(c));
    const machine = !ctx.length || ctx.includes("global");
    if (!agent && !machine) continue;
    const title = String(a.title || id).replace(/\s+/g, " ").trim().slice(0, 120) || id;
    const description = a.description ? String(a.description).replace(/\s+/g, " ").trim().slice(0, 240) || null : null;
    const pluginName = String((p == null ? void 0 : p.name) || plugin).trim() || plugin;
    out.push({
      plugin,
      pluginName,
      id,
      title,
      label: shortLabel(title, pluginName),
      description,
      agent,
      machine,
      confirm: needsConfirm({ id, title }),
      inHerdr: opensInHerdr(a)
    });
  }
  return out.sort((x, y) => x.pluginName.localeCompare(y.pluginName) || x.label.localeCompare(y.label));
}
const ANSI = /\x1B(?:\[[0-?]*[ -/]*[@-~]|\][^\x07\x1B]*(?:\x07|\x1B\\)|[@-Z\\-_])/g;
function stripAnsi(text) {
  return String(text || "").replace(ANSI, "").replace(/[\x00-\x08\x0B-\x1F\x7F]/g, "");
}
function outputTail(text, max = 300) {
  const lines = stripAnsi(text).split("\n").map((l) => l.trim()).filter(Boolean);
  let out = "";
  for (let i = lines.length - 1; i >= 0; i--) {
    const next = out ? `${lines[i]}
${out}` : lines[i];
    if (next.length > max) {
      if (!out) out = "\u2026" + lines[i].slice(-(max - 1));
      break;
    }
    out = next;
  }
  return out;
}
function logResult(log2) {
  const status = (log2 == null ? void 0 : log2.status) === "succeeded" || (log2 == null ? void 0 : log2.status) === "failed" ? log2.status : "running";
  const exitCode = typeof (log2 == null ? void 0 : log2.exit_code) === "number" ? log2.exit_code : null;
  const output = status === "failed" ? outputTail(log2 == null ? void 0 : log2.stderr) || outputTail(log2 == null ? void 0 : log2.error) || outputTail(log2 == null ? void 0 : log2.stdout) : outputTail(log2 == null ? void 0 : log2.stdout) || outputTail(log2 == null ? void 0 : log2.stderr);
  return { status, exitCode, output };
}

const CACHE_MS = 1e4;
const cache = /* @__PURE__ */ new Map();
async function listPluginActions(machineKey, fresh = false) {
  const m = machineFor(machineKey);
  const hit = cache.get(m.key);
  if (!fresh && hit && Date.now() - hit.at < CACHE_MS) return hit.actions;
  const [a, p] = await Promise.all([
    herdrOn(m.key, "plugin.action.list", {}, 8e3),
    herdrOn(m.key, "plugin.list", {}, 8e3).catch(() => ({ plugins: [] }))
  ]);
  const actions = normalizeActions(a.actions || [], p.plugins || []);
  cache.set(m.key, { at: Date.now(), actions });
  return actions;
}
const WAIT_MS = 12e3;
async function invokePluginAction(body) {
  const plugin = String(body.plugin || "");
  const action = String(body.action || "");
  if (!PLUGIN_ID_RE.test(plugin) || !ACTION_ID_RE.test(action)) throw new HerdrError("bad_action", "Invalid action");
  const paneId = body.pane_id ? String(body.pane_id) : "";
  const pane = paneId ? findPane(paneId) : null;
  if (paneId && !pane) throw new HerdrError("bad_pane", "Pane not found");
  const m = machineFor(pane ? splitId(pane.id).machine : body.machine);
  const known = (await listPluginActions(m.key, true)).find((a) => a.plugin === plugin && a.id === action);
  if (!known) throw new HerdrError("plugin_action_not_found", "Action not found on this machine");
  if (pane ? !known.agent : !known.machine) throw new HerdrError("bad_context", "Action not available here");
  const context = actionContext(pane || null, getState().workspaces);
  const r = await herdrOn(m.key, "plugin.action.invoke", { plugin_id: plugin, action_id: action, context }, 1e4);
  const logId = r.log && r.log.log_id;
  log(`plugin ${plugin}.${action}${pane ? ` (${pane.id})` : ""}${m.local ? "" : ` on ${m.label}`} started`);
  let last = r.log;
  const until = Date.now() + WAIT_MS;
  while (logId && logResult(last).status === "running" && Date.now() < until) {
    await sleep(400);
    const l = await herdrOn(m.key, "plugin.log.list", { plugin_id: plugin, limit: 20 }, 5e3).catch(() => null);
    last = (l && l.logs || []).find((x) => x.log_id === logId) || last;
  }
  const res = logResult(last);
  log(`plugin ${plugin}.${action}: ${res.status}${res.exitCode !== null ? ` (${res.exitCode})` : ""}`);
  return res;
}

export { invokePluginAction as i, listPluginActions as l };
//# sourceMappingURL=plugins.mjs.map

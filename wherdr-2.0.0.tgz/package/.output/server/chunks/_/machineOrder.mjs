import fs from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { aG as baseMachines, aH as DATA_DIR } from '../nitro/nitro.mjs';

function cleanMachineOrder(value, known) {
  if (!Array.isArray(value)) return [];
  const ok = new Set(known);
  return value.filter((key, index) => typeof key === "string" && ok.has(key) && value.indexOf(key) === index);
}
function validMachineOrder(order, known) {
  return Array.isArray(order) && order.length <= known.length && new Set(order).size === order.length && order.every((key) => typeof key === "string" && known.includes(key));
}

const file = path.join(DATA_DIR, "machine-order.json");
function currentMachineKeys() {
  return baseMachines().map((m) => m.key);
}
async function readMachineOrder() {
  try {
    return cleanMachineOrder(JSON.parse(await fs.readFile(file, "utf8")), currentMachineKeys());
  } catch {
    return [];
  }
}
async function writeMachineOrder(order) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  const temp = `${file}.${randomUUID()}.tmp`;
  try {
    await fs.writeFile(temp, JSON.stringify(order) + "\n", { mode: 384 });
    await fs.rename(temp, file);
  } catch (error) {
    await fs.rm(temp, { force: true }).catch(() => {
    });
    throw error;
  }
}

export { currentMachineKeys as c, readMachineOrder as r, validMachineOrder as v, writeMachineOrder as w };
//# sourceMappingURL=machineOrder.mjs.map

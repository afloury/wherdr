function posixResolve(base, p) {
  const out = [];
  for (const seg of (p.startsWith("/") ? p : `${base}/${p}`).split("/")) {
    if (seg === "" || seg === ".") continue;
    if (seg === "..") out.pop();
    else out.push(seg);
  }
  return "/" + out.join("/");
}
const POSITION = /:\d+(?::\d+)?$/;
const stripPosition = (s) => s.replace(POSITION, "");
function resolveAgentPath(written, cwd, home) {
  const p = stripPosition(String(written || "").trim());
  if (!p || !home.startsWith("/") || /[\0\n\r]/.test(p)) return null;
  const root = posixResolve("/", home);
  const inside = (r2) => r2 === root || r2.startsWith(root === "/" ? "/" : root + "/");
  const base = cwd && cwd.startsWith("/") && inside(posixResolve("/", cwd)) ? posixResolve("/", cwd) : root;
  const r = posixResolve(base, p.replace(/^~(?=$|\/)/, root));
  return inside(r) ? r : null;
}
const RUNNABLE = /\.(app|command|tool|terminal|pkg|mpkg|workflow|action|scpt|scptd|applescript|jar|sh|bash|zsh|csh|fish|py|rb|pl|webloc|inetloc|fileloc|prefpane|qlgenerator|saver|kext|osax|dmg)\/?$/i;
const runnablePath = (p) => RUNNABLE.test(p);

export { runnablePath as a, posixResolve as p, resolveAgentPath as r };
//# sourceMappingURL=filePaths.mjs.map

import { ck as networkReady, cl as ensureFresh, cm as gateDecision, cn as sameOrigin, co as hostAllowed, k as auth, cp as checkRequestClient, cq as onNetworkReading } from '../nitro/nitro.mjs';

var _a, _b;
const WS_MAX = 256 * 1024;
function headersOf(h) {
  const out = {};
  h.forEach((v, k) => {
    out[k] = v;
  });
  return out;
}
function upgradeVerdict(headers, remoteAddress) {
  return gateDecision({
    check: checkRequestClient(remoteAddress, headers),
    unlocked: auth.isUnlocked({ headers }),
    hostOk: hostAllowed(headers.host),
    crossSite: !sameOrigin(headers),
    path: "/ws",
    ws: true
  });
}
async function checkUpgrade(request) {
  var _a2, _b2;
  await networkReady();
  await ensureFresh(0);
  const verdict = upgradeVerdict(headersOf(request.headers), (_b2 = (_a2 = request._req) == null ? void 0 : _a2.socket) == null ? void 0 : _b2.remoteAddress);
  if (verdict === "network") return new Response(null, { status: 403, statusText: "Network not allowed" });
  if (verdict === "host") return new Response(null, { status: 403, statusText: "Host not allowed" });
  if (verdict === "origin") return new Response(null, { status: 403, statusText: "Forbidden" });
  if (verdict === "locked") return new Response(null, { status: 401, statusText: "Unauthorized" });
}
const rawWs = (peer) => {
  var _a2;
  return ((_a2 = peer._internal) == null ? void 0 : _a2.ws) || null;
};
const isOpen = (peer) => {
  var _a2, _b2;
  return ((_b2 = (_a2 = rawWs(peer)) == null ? void 0 : _a2.readyState) != null ? _b2 : 1) === 1;
};
const alive = /* @__PURE__ */ new Map();
function watchPeer(peer) {
  const ws = rawWs(peer);
  alive.set(peer, true);
  if (ws) ws.on("pong", () => alive.set(peer, true));
}
function unwatchPeer(peer) {
  alive.delete(peer);
}
function revalidatePeers(peers = alive.keys(), judge = upgradeVerdict) {
  var _a2;
  let closed = 0;
  for (const peer of [...peers]) {
    let verdict;
    try {
      verdict = judge(((_a2 = peer.request) == null ? void 0 : _a2.headers) ? headersOf(peer.request.headers) : {}, peer.remoteAddress);
    } catch {
      verdict = "network";
    }
    if (verdict === "ok") continue;
    closed++;
    alive.delete(peer);
    try {
      peer.close(1008, "Network policy changed");
    } catch {
    }
  }
  return closed;
}
onNetworkReading(() => {
  revalidatePeers();
});
(_b = (_a = setInterval(() => {
  for (const [peer, ok] of alive) {
    const ws = rawWs(peer);
    if (!ws) continue;
    if (!ok) {
      ws.terminate();
      alive.delete(peer);
      continue;
    }
    alive.set(peer, false);
    try {
      ws.ping();
    } catch {
    }
  }
}, 25e3)).unref) == null ? void 0 : _b.call(_a);
function messageText(message) {
  const t = message.text();
  return t.length > WS_MAX ? null : t;
}

export { checkUpgrade as c, isOpen as i, messageText as m, unwatchPeer as u, watchPeer as w };
//# sourceMappingURL=ws.mjs.map

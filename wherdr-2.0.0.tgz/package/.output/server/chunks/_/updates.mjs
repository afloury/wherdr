import { p as pkg } from './package.mjs';
import { c6 as installMode, c7 as oneTapMode, c8 as updateCommand, c9 as compareVersions } from '../nitro/nitro.mjs';

const REPO = "afloury/wherdr";
const RELEASES_URL = `https://api.github.com/repos/${REPO}/releases?per_page=100`;
const DAY_MS = 24 * 60 * 60 * 1e3;
const RETRY_MS = 60 * 60 * 1e3;
function createUpdateChecker(opts) {
  var _a;
  const now = (_a = opts.now) != null ? _a : Date.now;
  let cached = null;
  let nextAt = 0;
  let pending = null;
  async function refresh() {
    var _a2;
    try {
      const res = await opts.fetch(RELEASES_URL);
      if (!res.ok) throw new Error("http");
      const releases = await res.json();
      const body = releases.filter((r) => !r.draft && !r.prerelease && /^v\d+\.\d+\.\d+$/.test(String(r.tag_name))).sort((a, b) => compareVersions(String(b.tag_name), String(a.tag_name)))[0];
      if (!body || typeof body.tag_name !== "string") throw new Error("tag");
      const candidate = { version: body.tag_name.replace(/^v/, ""), url: typeof body.html_url === "string" ? body.html_url : "" };
      const mode = installMode(opts.env.WHERDR_INSTALL);
      if (mode === "plugin") {
        const archive = `https://github.com/${REPO}/releases/download/v${candidate.version}/wherdr-${candidate.version}.tgz`;
        if (!(await opts.fetch(archive)).ok || !(await opts.fetch(`${archive}.sha256`)).ok) {
          nextAt = now() + RETRY_MS;
          return;
        }
      }
      if (mode === "npm" || mode === "npm-global") {
        const registry = (opts.env.npm_config_registry || "https://registry.npmjs.org").replace(/\/$/, "");
        const available = await opts.fetch(`${registry}/wherdr/-/wherdr-${candidate.version}.tgz`);
        if (!available.ok) {
          nextAt = now() + RETRY_MS;
          return;
        }
        if (mode === "npm") {
          const latest = await opts.fetch(`${registry}/wherdr/latest`);
          if (!latest.ok || (await latest.json()).version !== candidate.version) {
            nextAt = now() + RETRY_MS;
            return;
          }
        }
      }
      if (mode === "brew") {
        const formula = await opts.fetch("https://raw.githubusercontent.com/afloury/homebrew-tap/main/Formula/wherdr.rb");
        const text = formula.ok ? await ((_a2 = formula.text) == null ? void 0 : _a2.call(formula)) : "";
        if (!(text == null ? void 0 : text.includes(`/v${candidate.version}/wherdr-${candidate.version}.tgz"`))) {
          nextAt = now() + RETRY_MS;
          return;
        }
      }
      cached = candidate;
      nextAt = now() + DAY_MS;
    } catch {
      nextAt = now() + RETRY_MS;
    }
  }
  return async function check() {
    const mode = installMode(opts.env.WHERDR_INSTALL);
    const base = { current: opts.current, mode, command: updateCommand(mode, REPO), oneTap: oneTapMode(mode) };
    if (String(opts.env.WHERDR_UPDATE_CHECK || "").toLowerCase() === "off") return { ...base, latest: null, url: null, checked: false };
    if (now() >= nextAt) {
      pending != null ? pending : pending = refresh().finally(() => {
        pending = null;
      });
      await pending;
    }
    const newer = cached && compareVersions(cached.version, opts.current) > 0;
    return { ...base, latest: newer ? cached.version : null, url: newer ? cached.url || null : null, checked: !!cached };
  };
}
function fetchUpdateResource(url, request = fetch) {
  return request(url, {
    method: /\.tgz(?:\.sha256)?$/.test(url) ? "HEAD" : "GET",
    headers: {
      ...new URL(url).hostname === "api.github.com" ? { accept: "application/vnd.github+json" } : {},
      "user-agent": "wherdr"
    },
    signal: AbortSignal.timeout(1e4)
  });
}
const checkUpdate = createUpdateChecker({
  current: pkg.version,
  env: process.env,
  fetch: fetchUpdateResource
});

export { REPO as R, checkUpdate as c };
//# sourceMappingURL=updates.mjs.map

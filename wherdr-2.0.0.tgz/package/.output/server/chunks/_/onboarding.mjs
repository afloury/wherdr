import fs from 'node:fs';
import path from 'node:path';
import { aW as HOST_LABEL, aH as DATA_DIR } from '../nitro/nitro.mjs';

const ONBOARDING_FILE = path.join(DATA_DIR, "onboarding.json");
function readOnboarding(file = ONBOARDING_FILE, host = HOST_LABEL) {
  try {
    const saved = JSON.parse(fs.readFileSync(file, "utf8"));
    return { done: saved.done === true && saved.host === host };
  } catch {
    return { done: false };
  }
}
function writeOnboarding(done, file = ONBOARDING_FILE, host = HOST_LABEL) {
  if (!done) {
    fs.rmSync(file, { force: true });
    return { done: false };
  }
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, `${JSON.stringify({ done: true, host, at: (/* @__PURE__ */ new Date()).toISOString() }, null, 2)}
`);
  return { done: true };
}

export { readOnboarding as r, writeOnboarding as w };
//# sourceMappingURL=onboarding.mjs.map

import { execFile } from 'node:child_process';
import path from 'node:path';
import { r as resolveAgentPath, p as posixResolve } from './filePaths.mjs';
import { g as gitToplevel } from './changes.mjs';
import { H as HerdrError } from '../nitro/nitro.mjs';

const MAX_ENTRIES = 2e3;
const TEXT_BYTES = 256 * 1024;
const IMAGE_BYTES = 2 * 1024 * 1024;
const DOWNLOAD_BYTES = 50 * 1024 * 1024;
const IMAGE_TYPES = {
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  gif: "image/gif",
  webp: "image/webp",
  avif: "image/avif",
  bmp: "image/bmp",
  ico: "image/x-icon",
  svg: "image/svg+xml"
};
const PDF_HEAD = 1024;
const isPdf = (name, head) => path.posix.extname(name).toLowerCase() === ".pdf" && head.subarray(0, PDF_HEAD).includes("%PDF-");
const VIDEO_TYPES = { mp4: "video/mp4", m4v: "video/mp4", mov: "video/quicktime", webm: "video/webm" };
const VIDEO_HEAD = 12;
const MP4_BOXES = /* @__PURE__ */ new Set(["ftyp", "moov", "mdat", "wide", "free", "skip", "pnot"]);
const videoType = (name) => VIDEO_TYPES[path.posix.extname(name).slice(1).toLowerCase()];
function isVideo(name, head) {
  const type = videoType(name);
  if (!type || head.length < 8) return false;
  if (type === "video/webm") return head.readUInt32BE(0) === 440786851;
  return MP4_BOXES.has(head.subarray(4, 8).toString("latin1"));
}
const RESOLVE = `root=$(cd "$1" 2>/dev/null && pwd -P) || { echo "folder not found" >&2; exit 3; }
under() { case "$1/" in "\${root%/}/"*) return 0 ;; esac; return 1; }`;
const LIST_SCRIPT = `${RESOLVE}
if [ -n "$4" ]; then
  dir=$(cd "$4" 2>/dev/null && pwd -P) && under "$dir" || dir=$root
else
  dir=$(cd "$root" && cd -- "./$2" 2>/dev/null && pwd -P) || { echo "not found" >&2; exit 4; }
  under "$dir" || { echo "outside" >&2; exit 5; }
fi
cd "$dir" || exit 4
e=$(LC_ALL=C ls -A 2>&1 >/dev/null) || {
  case "$e" in *"not permitted"*) [ "$(uname -s)" = Darwin ] && exit 8 ;; esac
  echo "permission denied" >&2; exit 7
}
printf '%s\\0%s\\0' "$root" "$dir"
max=$3; n=0
set --
for pass in d o; do
  for f in * .[!.]* ..?*; do
    [ -e "$f" ] || [ -L "$f" ] || continue
    if [ -d "$f" ]; then t=d; elif [ -f "$f" ]; then t=f; else t=o; fi
    if [ "$pass" = d ]; then [ "$t" = d ] || continue; else [ "$t" != d ] || continue; fi
    n=$((n + 1)); [ "$n" -gt "$max" ] && { printf '+\\0'; break 2; }
    if [ -L "$f" ]; then l=l; else l=' '; [ "$t" = f ] && set -- "$@" "$f"; fi
    printf '%s%s %s\\0' "$t" "$l" "$f"
  done
done
printf '=\\0'
[ "$#" -gt 0 ] || exit 0
if stat -f %z / >/dev/null 2>&1; then stat -f %z -- "$@"; else stat -c %s -- "$@"; fi 2>/dev/null
exit 0`;
const OPEN_FILE = `${RESOLVE}
case "$2" in */*) d=\${2%/*} ;; *) d=. ;; esac
b=\${2##*/}
dir=$(cd "$root" && cd -- "./$d" 2>/dev/null && pwd -P) || { echo "not found" >&2; exit 4; }
f="$dir/$b"; i=0
while [ -L "$f" ]; do
  i=$((i + 1)); [ "$i" -gt 40 ] && { echo "not found" >&2; exit 4; }
  t=$(readlink -- "$f") || exit 4
  case "$t" in /*) f=$t ;; *) f="\${f%/*}/$t" ;; esac
  p=\${f%/*}
  dir=$(cd -P -- "\${p:-/}" 2>/dev/null && pwd -P) || { echo "not found" >&2; exit 4; }
  f="\${dir%/}/\${f##*/}"
done
[ -e "$f" ] || { echo "not found" >&2; exit 4; }
under "$f" || { echo "outside" >&2; exit 5; }
[ -f "$f" ] || { echo "not a file" >&2; exit 6; }
[ -r "$f" ] || { echo "permission denied" >&2; exit 7; }
command exec 3< "$f" || { echo "permission denied" >&2; exit 7; }
# "<inode> <size> <mtime> <version>" of the opened file, from its metadata:
# never a read (BusyBox's wc -c reads every byte). <version>: modification
# and change times to the nanosecond (GNU/BusyBox, then BSD). Without the
# descriptor's metadata, the path's, with no <version>: never a strong ETag.
meta() {
  stat -L -c '%i %s %Y %y %z' /dev/fd/3 2>/dev/null || stat -L -f '%i %z %m %Fm %Fc' /dev/fd/3 2>/dev/null ||
  stat -L -c '%i %s %Y' "$f" 2>/dev/null || stat -L -f '%i %z %m' "$f" 2>/dev/null || echo "0 $(wc -c < "$f") 0"
}`;
const READ_SCRIPT = `${OPEN_FILE}
m=$(meta) || exit 4
s=\${m#* }; s=$((\${s%% *}))
echo $s
[ -n "$4" ] && [ "$s" -ge "$3" ] && exit 0
head -c "$3" <&3`;
const MACOS_SSH_DENIED = "macOS blocks access to this folder. On the Mac: System Settings \u203A General \u203A Sharing \u203A Remote Login \u24D8 \u203A \u201CAllow full disk access for remote users\u201D.";
const MACOS_LOCAL_DENIED = "macOS blocks access to this folder. Allow the app that runs wherdr in System Settings \u203A Privacy & Security \u203A Full Disk Access.";
function executor(m, { timeoutMs = 15e3, maxBytes = IMAGE_BYTES } = {}) {
  const remote = m.exec;
  if (remote) return (script, args) => remote(script, args, { timeoutMs });
  return (script, args) => new Promise((resolve) => {
    execFile("sh", ["-c", script, "sh", ...args], { timeout: timeoutMs, encoding: "buffer", maxBuffer: maxBytes + 64 * 1024 }, (err, out, stderr) => {
      const e = err;
      const code = !e ? 0 : e.killed ? 124 : typeof e.code === "number" ? e.code : 1;
      resolve({ code, stdout: out, stderr: String(stderr || "") });
    });
  });
}
async function run(m, script, args, opts) {
  const r = await executor(m, opts)(script, args);
  if (r.code === 0) return r.stdout;
  throw shellError(m, r.code, r.stderr);
}
function shellError(m, code, stderr) {
  const r = { code, stderr };
  if (r.code === 3) return new HerdrError("bad_cwd", "This agent\u2019s folder is unknown");
  if (r.code === 4) return new HerdrError("not_found", "File not found");
  if (r.code === 5) return new HerdrError("outside", "Outside the project folder");
  if (r.code === 6) return new HerdrError("not_file", "Not a file");
  if (r.code === 7) return new HerdrError("denied", "Permission denied");
  if (r.code === 8) return new HerdrError("denied", m.exec ? MACOS_SSH_DENIED : MACOS_LOCAL_DENIED);
  if (r.code === 124) return new HerdrError("timeout", "The folder took too long to read");
  if (r.code === 255 || r.code === null) return new HerdrError("unreachable", "Machine unreachable");
  return new HerdrError("remote", r.stderr.trim().split("\n").pop() || `code ${r.code}`);
}
function cleanRelative(p) {
  const raw = String(p != null ? p : "").replace(/\\/g, "/");
  if (raw.startsWith("/") || raw.includes("\0")) throw new HerdrError("outside", "Outside the project folder");
  const n = path.posix.normalize(raw || ".").replace(/\/+$/, "");
  if (n === ".." || n.startsWith("../")) throw new HerdrError("outside", "Outside the project folder");
  return n === "." ? "" : n;
}
function parseListing(raw) {
  const parts = raw.toString("utf8").split("\0");
  const root = parts[0] || "";
  const dir = parts[1] || "";
  const entries = [];
  const plain = [];
  let truncated = false;
  let i = 2;
  for (; i < parts.length; i++) {
    const p = parts[i];
    if (p === "=") break;
    if (p === "+") {
      truncated = true;
      continue;
    }
    const m = /^([dfo])([l ]) (.+)$/s.exec(p);
    if (!m) continue;
    const e = { name: m[3], kind: m[1] === "d" ? "dir" : m[1] === "f" ? "file" : "other", size: null, link: m[2] === "l" };
    entries.push(e);
    if (e.kind === "file" && !e.link) plain.push(e);
  }
  const sizes = parts.slice(i + 1).join("").split("\n").filter((l) => /^\d+$/.test(l)).map(Number);
  if (sizes.length === plain.length) plain.forEach((e, k) => {
    e.size = sizes[k];
  });
  entries.sort((a, b) => Number(b.kind === "dir") - Number(a.kind === "dir") || a.name.localeCompare(b.name, void 0, { numeric: true, sensitivity: "base" }));
  return { root, dir, entries, truncated };
}
async function rootOf(m, cwd, signal) {
  return await gitToplevel(m, cwd, signal) || cwd;
}
async function listFiles(m, cwd, rel, opts = {}) {
  var _a, _b;
  const root = await rootOf(m, cwd);
  const args = rel === null ? [root, "", String((_a = opts.max) != null ? _a : MAX_ENTRIES), cwd] : [root, cleanRelative(rel), String((_b = opts.max) != null ? _b : MAX_ENTRIES)];
  const out = parseListing(await run(m, LIST_SCRIPT, args));
  const rp = path.posix.relative(out.root, out.dir);
  return { root: out.root, path: rp.startsWith("..") ? "" : rp, entries: out.entries, truncated: out.truncated };
}
const isText = (b) => !b.subarray(0, 8192).includes(0);
function cutAt(b, max) {
  const nl = b.lastIndexOf(10, max - 1);
  if (nl >= 0) return nl + 1;
  let i = max;
  while (i > 0 && (b[i] & 192) === 128) i--;
  return i;
}
function writtenTarget(m, cwd, written) {
  const w = String(written != null ? written : "");
  const abs = w.length > 1024 ? null : resolveAgentPath(w, cwd, m.home);
  if (!abs) throw new HerdrError("outside_home", "Only files in your home folder can be shown");
  const root = posixResolve("/", m.home);
  const rel = path.posix.relative(root, abs);
  if (!rel) throw new HerdrError("not_file", "Not a file");
  return { root, rel, abs };
}
async function readHead(m, root, rel, max, opts) {
  const out = await run(m, READ_SCRIPT, [root, rel, String(max), ...(opts == null ? void 0 : opts.whole) ? ["1"] : []], opts);
  const nl = out.indexOf(10);
  return { size: Number(out.subarray(0, nl).toString("utf8")) || 0, body: out.subarray(nl + 1) };
}
async function previewAt(m, root, rel, shown) {
  const ext = path.posix.extname(rel).slice(1).toLowerCase();
  const mime = IMAGE_TYPES[ext];
  const video = VIDEO_TYPES[ext];
  const { size, body } = await readHead(m, root, rel, mime ? IMAGE_BYTES + 1 : ext === "pdf" ? PDF_HEAD : video ? VIDEO_HEAD : TEXT_BYTES + 1);
  if (video) return { path: shown, size, kind: isVideo(rel, body) ? "video" : "binary", truncated: false };
  if (ext === "pdf") {
    if (!isPdf(rel, body)) return { path: shown, size, kind: "binary", truncated: false };
    return { path: shown, size, kind: size > DOWNLOAD_BYTES ? "large" : "pdf", truncated: false };
  }
  if (mime) {
    if (size > IMAGE_BYTES) return { path: shown, size, kind: "large", truncated: true };
    return { path: shown, size, kind: "image", dataUrl: `data:${mime};base64,${body.toString("base64")}`, truncated: false };
  }
  if (!isText(body)) return { path: shown, size, kind: "binary", truncated: false };
  const truncated = body.length > TEXT_BYTES;
  const text = (truncated ? body.subarray(0, cutAt(body, TEXT_BYTES)) : body).toString("utf8");
  return { path: shown, size, kind: "text", text, truncated };
}
async function readFilePreview(m, cwd, rel) {
  const p = cleanRelative(rel);
  if (!p) throw new HerdrError("not_file", "Not a file");
  return previewAt(m, await rootOf(m, cwd), p, p);
}
async function readWrittenPreview(m, cwd, written) {
  const t = writtenTarget(m, cwd, written);
  return previewAt(m, t.root, t.rel, t.abs);
}
async function bytesAt(m, root, rel) {
  const { size, body } = await readHead(m, root, rel, DOWNLOAD_BYTES + 1, { timeoutMs: 12e4, maxBytes: DOWNLOAD_BYTES + 1, whole: true });
  if (size > DOWNLOAD_BYTES || body.length > DOWNLOAD_BYTES) throw new HerdrError("too_large", "File too large to download (50 MB max)");
  return { name: path.posix.basename(rel), body };
}
async function readFileBytes(m, cwd, rel) {
  const p = cleanRelative(rel);
  if (!p) throw new HerdrError("not_file", "Not a file");
  return bytesAt(m, await rootOf(m, cwd), p);
}
async function readWrittenBytes(m, cwd, written) {
  const t = writtenTarget(m, cwd, written);
  return bytesAt(m, t.root, t.rel);
}
function attachmentHeader(name, type = "attachment") {
  const ascii = name.replace(/[^\x20-\x7e]|["\\]/g, "_") || "download";
  const utf8 = encodeURIComponent(name).replace(/['()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`);
  return `${type}; filename="${ascii}"; filename*=UTF-8''${utf8}`;
}

export { OPEN_FILE as O, VIDEO_HEAD as V, readWrittenBytes as a, readFileBytes as b, cleanRelative as c, isPdf as d, attachmentHeader as e, readWrittenPreview as f, readFilePreview as g, isVideo as i, listFiles as l, rootOf as r, shellError as s, videoType as v, writtenTarget as w };
//# sourceMappingURL=files.mjs.map

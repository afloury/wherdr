import { s as sendError, cd as useStorage, aw as setResponseHeader } from '../nitro/nitro.mjs';
import fs from 'node:fs';
import path from 'node:path';

const BRANDING_DIR = process.env.BRANDING_DIR || "";
const TYPES = { png: "image/png", svg: "image/svg+xml", ico: "image/x-icon" };
async function serveBranding(event, rel) {
  if (!/^(icons\/[\w.-]+\.(png|svg)|favicon\.ico)$/.test(rel)) return sendError(event, 404, { error: "Not found" });
  let body = null;
  if (BRANDING_DIR) {
    try {
      body = await fs.promises.readFile(path.join(BRANDING_DIR, rel));
    } catch {
      body = null;
    }
  }
  if (!body) {
    const raw = await useStorage("assets:server").getItemRaw(`branding/${rel}`);
    body = raw ? Buffer.from(raw) : null;
  }
  if (!body) return sendError(event, 404, { error: "Not found" });
  setResponseHeader(event, "content-type", TYPES[rel.split(".").pop()]);
  setResponseHeader(event, "cache-control", "public, max-age=86400");
  return body;
}

export { serveBranding as s };
//# sourceMappingURL=branding.mjs.map

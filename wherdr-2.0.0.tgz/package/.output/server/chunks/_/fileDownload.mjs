import { H as HerdrError, a as defineApi, i as getQuery, f as findPane, m as machineFor, aw as setResponseHeader, ax as getRequestHeader, ay as setResponseStatus } from '../nitro/nitro.mjs';
import { w as writtenTarget, c as cleanRelative, r as rootOf, i as isVideo, O as OPEN_FILE, V as VIDEO_HEAD, s as shellError, v as videoType, a as readWrittenBytes, b as readFileBytes, d as isPdf, e as attachmentHeader } from './files.mjs';
import { spawn } from 'node:child_process';
import crypto from 'node:crypto';
import path from 'node:path';
import { Readable } from 'node:stream';

const VIDEO_BLOCK = 64 * 1024;
const OPEN_TIMEOUT_MS = 15e3;
const STREAM_SCRIPT = `${OPEN_FILE}
m=$(meta) || exit 4
echo "$(date +%s) $m"
dd bs=${VIDEO_HEAD} count=1 <&3 2>/dev/null
read skip count || exit 0
[ "$count" -gt 0 ] 2>/dev/null || exit 0
exec dd bs=${VIDEO_BLOCK} skip="$skip" count="$count" <&3 2>/dev/null`;
function parseRange(header, size) {
  var _a;
  if (header === void 0) return { kind: "full" };
  const m = /^bytes[ \t]*=[ \t]*(.*)$/i.exec(header.trim());
  if (!m) return { kind: "full" };
  const specs = m[1].split(",").map((x) => x.trim()).filter(Boolean);
  if (!specs.length) return { kind: "full" };
  const parsed = [];
  for (const spec of specs) {
    const r = /^(\d*)-(\d*)$/.exec(spec);
    if (!r || !r[1] && !r[2]) return { kind: "full" };
    if (!r[1]) parsed.push({ suffix: Number(r[2]) });
    else {
      const first = Number(r[1]);
      const last = r[2] ? Number(r[2]) : void 0;
      if (last !== void 0 && last < first) return { kind: "full" };
      parsed.push({ first, last });
    }
  }
  for (const p of parsed) {
    if (p.suffix !== void 0) {
      if (p.suffix > 0 && size > 0) return { kind: "part", start: Math.max(0, size - p.suffix), end: size - 1 };
    } else if (p.first < size) {
      return { kind: "part", start: p.first, end: Math.min((_a = p.last) != null ? _a : size - 1, size - 1) };
    }
  }
  return { kind: "none" };
}
function answer(v, req) {
  let range = req.method === "HEAD" ? void 0 : req.range;
  if (range !== void 0 && req.ifRange !== void 0 && (req.ifRange.trim() !== v.etag || v.etag.startsWith("W/"))) range = void 0;
  const r = parseRange(range, v.size);
  if (r.kind === "none") return { status: 416, start: 0, len: 0, contentRange: `bytes */${v.size}` };
  if (r.kind === "full") return { status: 200, start: 0, len: v.size };
  return { status: 206, start: r.start, len: r.end - r.start + 1, contentRange: `bytes ${r.start}-${r.end}/${v.size}` };
}
function videoEtag(meta) {
  var _a;
  const frac = ((_a = /\.(\d+)/.exec(meta.version)) == null ? void 0 : _a[1]) || "";
  const strong = /[1-9]/.test(frac) && meta.now - meta.mtime >= 2;
  const hash = crypto.createHash("sha1").update(`${meta.ino}|${meta.size}|${meta.version}`).digest("hex").slice(0, 20);
  return `${strong ? "" : "W/"}"${hash}"`;
}
function cutOnError(res, body) {
  body.once("error", () => res.destroy());
  return body;
}
function readPlan(start, len, head) {
  const fromHead = start < head ? Math.min(len, head - start) : 0;
  const rest = len - fromHead;
  if (rest <= 0) return { fromHead, skip: 0, count: 0, drop: 0 };
  const at = start + fromHead - head;
  const skip = Math.floor(at / VIDEO_BLOCK);
  const drop = at - skip * VIDEO_BLOCK;
  return { fromHead, skip, count: Math.ceil((drop + rest) / VIDEO_BLOCK), drop };
}
function spawnScript(m, args) {
  var _a;
  if (!m.exec) {
    return spawn("sh", ["-c", STREAM_SCRIPT, "sh", ...args], { stdio: ["pipe", "pipe", "pipe"], detached: true });
  }
  const child = (_a = m.spawnShell) == null ? void 0 : _a.call(m, STREAM_SCRIPT, args);
  if (!child) throw new HerdrError("unreachable", "Machine unreachable");
  return child;
}
function kill(child, local) {
  if (child.exitCode !== null || child.signalCode !== null) return;
  try {
    if (local && child.pid) process.kill(-child.pid, "SIGKILL");
    else child.kill("SIGKILL");
  } catch {
  }
}
const closedError = () => new HerdrError("closed", "Request closed");
async function openAt(m, root, rel, signal) {
  if (signal == null ? void 0 : signal.aborted) throw closedError();
  const child = spawnScript(m, [root, rel]);
  const done = new Promise((resolve) => {
    child.on("close", () => resolve());
    child.on("error", () => resolve());
  });
  const local = !m.exec;
  const close = () => kill(child, local);
  child.stdin.on("error", () => {
  });
  let buf = Buffer.alloc(0);
  let stderr = "";
  child.stderr.on("data", (b) => {
    if (stderr.length < 4e3) stderr += b.toString("utf8");
  });
  const opened = await new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      close();
      reject(new HerdrError("timeout", "The folder took too long to read"));
    }, OPEN_TIMEOUT_MS);
    const onAbort = () => done2(() => {
      close();
      reject(closedError());
    });
    signal == null ? void 0 : signal.addEventListener("abort", onAbort, { once: true });
    const done2 = (f) => {
      clearTimeout(timer);
      signal == null ? void 0 : signal.removeEventListener("abort", onAbort);
      child.stdout.off("data", onData);
      child.off("close", onClose);
      child.off("error", onError);
      f();
    };
    const onData = (b) => {
      buf = Buffer.concat([buf, b]);
      const nl = buf.indexOf(10);
      if (nl < 0) return;
      const [now = "0", ino = "0", size = "0", mtime = "0", ...version] = buf.subarray(0, nl).toString("utf8").trim().split(/\s+/);
      const n = Number(size) || 0;
      const headLen = Math.min(VIDEO_HEAD, n);
      if (buf.length - nl - 1 < headLen) return;
      child.stdout.pause();
      const head = buf.subarray(nl + 1, nl + 1 + headLen);
      done2(() => resolve({ now: Number(now) || 0, ino, size: n, mtime: Number(mtime) || 0, version: version.join(" "), head }));
    };
    const onClose = (code) => done2(() => reject(code === 0 ? new HerdrError("not_found", "File not found") : shellError(m, code, stderr)));
    const onError = () => done2(() => reject(new HerdrError("unreachable", "Machine unreachable")));
    child.stdout.on("data", onData);
    child.on("close", onClose);
    child.on("error", onError);
  });
  const name = path.posix.basename(rel);
  if (!isVideo(name, opened.head)) {
    close();
    throw new HerdrError("not_video", "Not a video");
  }
  let reading = false;
  return {
    name,
    size: opened.size,
    mtime: opened.mtime,
    etag: videoEtag(opened),
    close,
    done,
    read(start, len) {
      if (reading) throw new Error("read once");
      reading = true;
      const plan = readPlan(start, len, opened.head.length);
      child.stdin.end(`${plan.skip} ${plan.count}
`);
      const out = child.stdout;
      async function* bytes() {
        let left = len;
        try {
          if (plan.fromHead) {
            yield opened.head.subarray(start, start + plan.fromHead);
            left -= plan.fromHead;
          }
          let drop = plan.drop;
          for await (const chunk of out) {
            if (left <= 0) break;
            let c = chunk;
            if (drop) {
              const n = Math.min(drop, c.length);
              c = c.subarray(n);
              drop -= n;
            }
            if (!c.length) continue;
            if (c.length > left) c = c.subarray(0, left);
            left -= c.length;
            yield c;
            if (left <= 0) break;
          }
          if (left > 0) throw new HerdrError("truncated", "The file shrank while being read");
        } finally {
          close();
        }
      }
      return Readable.from(bytes(), { objectMode: false });
    }
  };
}
function untilClosed(p, signal) {
  if (!signal) return p;
  if (signal.aborted) return Promise.reject(closedError());
  return new Promise((resolve, reject) => {
    const onAbort = () => reject(closedError());
    signal.addEventListener("abort", onAbort, { once: true });
    p.then(resolve, reject).finally(() => signal.removeEventListener("abort", onAbort));
  });
}
async function openVideo(m, cwd, rel, signal) {
  if (signal == null ? void 0 : signal.aborted) throw closedError();
  const p = cleanRelative(rel);
  if (!p) throw new HerdrError("not_file", "Not a file");
  const root = await untilClosed(rootOf(m, cwd, signal), signal);
  if (signal == null ? void 0 : signal.aborted) throw closedError();
  return openAt(m, root, p, signal);
}
async function openWrittenVideo(m, cwd, written, signal) {
  const t = writtenTarget(m, cwd, written);
  return openAt(m, t.root, t.rel, signal);
}

async function serveVideo(event, p, q, type) {
  const m = machineFor(p.machine);
  const res = event.node.res;
  const closed = new AbortController();
  res.once("close", () => closed.abort());
  if (res.destroyed) closed.abort();
  const v = q.from === "chat" ? await openWrittenVideo(m, p.cwd, q.path, closed.signal) : await openVideo(m, p.cwd, q.path, closed.signal);
  if (closed.signal.aborted) {
    v.close();
    return "";
  }
  closed.signal.addEventListener("abort", v.close, { once: true });
  try {
    setResponseHeader(event, "x-content-type-options", "nosniff");
    setResponseHeader(event, "accept-ranges", "bytes");
    setResponseHeader(event, "content-security-policy", "default-src 'none'; media-src 'self'; frame-ancestors 'self'");
    setResponseHeader(event, "etag", v.etag);
    setResponseHeader(event, "last-modified", new Date(v.mtime * 1e3).toUTCString());
    const a = answer(v, { method: event.method, range: getRequestHeader(event, "range"), ifRange: getRequestHeader(event, "if-range") });
    setResponseStatus(event, a.status);
    if (a.contentRange) setResponseHeader(event, "content-range", a.contentRange);
    if (a.status === 416) {
      v.close();
      setResponseHeader(event, "content-type", "text/plain");
      return "";
    }
    setResponseHeader(event, "content-type", type);
    setResponseHeader(event, "content-disposition", attachmentHeader(v.name, "inline"));
    setResponseHeader(event, "content-length", a.len);
    if (event.method === "HEAD" || !a.len) {
      v.close();
      return "";
    }
    return cutOnError(res, v.read(a.start, a.len));
  } catch (e) {
    v.close();
    throw e;
  }
}
const fileDownload = defineApi(async (event) => {
  const q = getQuery(event);
  const p = findPane(String(q.pane || ""));
  if (!p) throw new HerdrError("bad_pane", "Pane not found");
  if (q.from !== "chat" && !p.cwd) throw new HerdrError("bad_cwd", "This agent\u2019s folder is unknown");
  const video = q.inline === "1" ? videoType(String(q.path || "")) : void 0;
  if (video) return serveVideo(event, p, q, video);
  const f = q.from === "chat" ? await readWrittenBytes(machineFor(p.machine), p.cwd, q.path) : await readFileBytes(machineFor(p.machine), p.cwd, q.path);
  setResponseHeader(event, "x-content-type-options", "nosniff");
  if (q.inline === "1" && isPdf(f.name, f.body)) {
    setResponseHeader(event, "content-type", "application/pdf");
    setResponseHeader(event, "content-disposition", attachmentHeader(f.name, "inline"));
    setResponseHeader(event, "content-security-policy", "default-src 'none'; object-src 'self'; frame-ancestors 'self'");
    setResponseHeader(event, "cache-control", "private, no-store");
    return f.body;
  }
  setResponseHeader(event, "content-type", "application/octet-stream");
  setResponseHeader(event, "content-disposition", attachmentHeader(f.name));
  setResponseHeader(event, "content-security-policy", "default-src 'none'; sandbox");
  return f.body;
});

export { fileDownload as f };
//# sourceMappingURL=fileDownload.mjs.map

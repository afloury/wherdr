import { spawnSync, spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { p as pkg } from './package.mjs';
import { c6 as installMode, H as HerdrError, aa as log, c7 as oneTapMode, ca as updateRunning } from '../nitro/nitro.mjs';
import { c as checkUpdate, R as REPO } from './updates.mjs';

function wherdrDir(env = process.env) {
  const home = os.homedir();
  const dir = env.WHERDR_DIR || path.join(home, "wherdr");
  return path.resolve(dir === "~" ? home : dir.startsWith("~/") ? path.join(home, dir.slice(2)) : dir);
}
function readJob(dir) {
  try {
    const job = JSON.parse(fs.readFileSync(path.join(dir, "update.json"), "utf8"));
    return job && typeof job.state === "string" ? job : null;
  } catch {
    return null;
  }
}
function buildPlan(o) {
  if (!oneTapMode(o.mode)) throw new HerdrError("update_manual", "This installation cannot update itself: run the update command");
  if (updateRunning(o.job, o.now)) throw new HerdrError("update_running", "An update is already in progress");
  if (!o.latest || o.to !== o.latest) throw new HerdrError("update_version", "No newer version to install");
  return {
    kind: o.mode,
    from: o.current,
    to: o.latest,
    root: o.root,
    dir: o.dir,
    runtime: o.runtime,
    serverPid: o.pid,
    port: String(o.env.NITRO_PORT || o.env.PORT || 3e3),
    host: String(o.env.NITRO_HOST || o.env.HOST || "127.0.0.1"),
    releaseBase: `https://github.com/${REPO}/releases/download`,
    registry: o.env.npm_config_registry || "https://registry.npmjs.org"
  };
}
const packageRoot = () => process.env.WHERDR_ROOT || path.resolve(path.dirname(process.argv[1] || ""), "..", "..");
async function startUpdate(to) {
  const dir = wherdrDir();
  const info = await checkUpdate();
  const root = packageRoot();
  const plan = buildPlan({
    mode: installMode(process.env.WHERDR_INSTALL),
    current: pkg.version,
    latest: info.latest,
    to,
    job: readJob(dir),
    now: Date.now(),
    root,
    dir,
    runtime: process.execPath,
    pid: process.pid,
    env: process.env
  });
  const source = path.join(root, "bin", "lib", "updater.mjs");
  if (!fs.existsSync(source)) throw new HerdrError("update_manual", "The updater is missing from this installation: run the update command");
  const work = path.join(dir, "update");
  fs.mkdirSync(work, { recursive: true });
  const updater = path.join(work, "updater.mjs");
  const planFile = path.join(work, "plan.json");
  fs.copyFileSync(source, updater);
  fs.writeFileSync(planFile, `${JSON.stringify(plan, null, 2)}
`);
  const now = Date.now();
  const job = { state: "installing", from: plan.from, to: plan.to, mode: plan.kind, startedAt: now, updatedAt: now };
  fs.writeFileSync(path.join(dir, "update.json"), `${JSON.stringify(job)}
`);
  const out = fs.openSync(path.join(dir, "update.log"), "a");
  const scoped = !!process.env.INVOCATION_ID && spawnSync("systemd-run", ["--version"], { stdio: "ignore" }).status === 0;
  const [cmd, args] = scoped ? ["systemd-run", ["--user", "--scope", "--collect", "--quiet", process.execPath, updater, planFile]] : [process.execPath, [updater, planFile]];
  const child = spawn(cmd, args, { cwd: dir, env: process.env, detached: true, stdio: ["ignore", out, out] });
  fs.closeSync(out);
  child.on("error", (e) => log(`update: ${e.message}`));
  child.unref();
  log(`update: ${plan.from} \u2192 ${plan.to} (${plan.kind}) started, pid ${child.pid}`);
  return job;
}

export { readJob as r, startUpdate as s, wherdrDir as w };
//# sourceMappingURL=selfupdate.mjs.map

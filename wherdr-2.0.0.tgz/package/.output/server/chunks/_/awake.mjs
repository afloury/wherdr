import { execFile } from 'node:child_process';
import { H as HerdrError } from '../nitro/nitro.mjs';

const OURS = `cmdline() {
  if [ -r "\${AWAKE_PROC:-/proc}/$1/cmdline" ]; then tr '\\000' ' ' < "\${AWAKE_PROC:-/proc}/$1/cmdline"
  else ps -p "$1" -o args= 2>/dev/null; fi
}
started() {
  if [ -r "\${AWAKE_PROC:-/proc}/$1/stat" ]; then sed 's/.*) //' "\${AWAKE_PROC:-/proc}/$1/stat" | cut -d' ' -f20
  else LC_ALL=C TZ=UTC0 ps -p "$1" -o lstart= 2>/dev/null | sed 's/ *$//'; fi
}
legacy_started() {
  [ ! -r "\${AWAKE_PROC:-/proc}/$1/stat" ] && ps -p "$1" -o lstart= 2>/dev/null | sed 's/ *$//'
}
ours() {
  case "$1" in *[!0-9]*|'') return 1;; esac
  case "$(cmdline "$1")" in
    caffeinate\\ -i*|*/caffeinate\\ -i*|systemd-inhibit\\ --what=idle:sleep*|*/systemd-inhibit\\ --what=idle:sleep*) ;;
    *) return 1;;
  esac
  [ -z "\${2:-}" ] || [ "$(started "$1")" = "$2" ] || [ "$(legacy_started "$1")" = "$2" ]
}
running() {
  kill -0 "$1" 2>/dev/null || return 1
  [ ! -r "\${AWAKE_PROC:-/proc}/$1/stat" ] || [ "$(sed 's/.*) //' "\${AWAKE_PROC:-/proc}/$1/stat" | cut -d' ' -f1)" != Z ]
}`;
const STATUS_SCRIPT = `${OURS}
platform=$(uname -s)
case "$platform" in Darwin) platform=mac;; Linux) platform=linux;; *) platform=other;; esac
echo "platform=$platform"
echo "clock=$(date +%H%M)"
if [ "$platform" = mac ]; then pmset -g batt 2>/dev/null; fi
if [ "$platform" = linux ]; then command -v systemd-inhibit >/dev/null 2>&1 && echo "inhibit=1"; fi
d="$HOME/.cache/herdr-web/awake.pid"
if [ -f "$d" ]; then
  IFS='|' read -r pid until lid start < "$d" || true
  case "$until" in *[!0-9]*|'') until=0;; esac
  if ours "$pid" "\${start:-}" && { [ "$until" -eq 0 ] || [ "$until" -gt "$(date +%s)" ]; }; then
    echo "awake=$pid|$until|$lid"
  else rm -f "$d"; fi
fi`;
const CONTROL_SCRIPT = `set -u
${OURS}
mode=$1; lid=$2
dir="$HOME/.cache/herdr-web"; d="$dir/awake.pid"
mkdir -p "$dir"
fail() { echo "error=$1"; exit 0; }
platform=$(uname -s)
now=$(date +%s)
old_pid=; old_until=0; old_lid=0; old_start=
if [ -f "$d" ]; then IFS='|' read -r old_pid old_until old_lid old_start < "$d" || true; fi
case "$old_until" in *[!0-9]*|'') old_until=0;; esac
ours "$old_pid" "$old_start" || old_pid=
if [ "$mode" = off ]; then
  [ -z "$old_pid" ] || kill "$old_pid" 2>/dev/null || true
  rm -f "$d"; echo "stopped"; exit 0
fi
case "$mode" in
  hour) seconds=3600;; fourHours) seconds=14400;;
  evening) hour=$(expr "$(date +%H)" + 0); minute=$(expr "$(date +%M)" + 0); seconds=$(( (20 - hour) * 3600 - minute * 60 )); [ "$seconds" -gt 0 ] || fail evening_past;;
  untilOff) seconds=0;;
  extend) { [ -n "$old_pid" ] && [ "$old_until" -gt "$now" ]; } || fail not_active; seconds=$((old_until - now + 3600));;
  *) fail bad_mode;;
esac
until=0; [ "$seconds" -eq 0 ] || until=$((now + seconds))
if [ "$platform" = Darwin ]; then
  command -v caffeinate >/dev/null 2>&1 || fail no_tool
  flags=-i; [ "$lid" != 1 ] || flags="-i -s"
  if [ "$seconds" -eq 0 ]; then nohup caffeinate $flags </dev/null >/dev/null 2>&1 &
  else nohup caffeinate $flags -t "$seconds" </dev/null >/dev/null 2>&1 & fi
elif [ "$platform" = Linux ]; then
  command -v systemd-inhibit >/dev/null 2>&1 || fail no_tool
  [ "$lid" = 0 ] || fail lid_mac_only
  if [ "$seconds" -eq 0 ]; then nohup systemd-inhibit --what=idle:sleep sleep infinity </dev/null >/dev/null 2>&1 &
  else nohup systemd-inhibit --what=idle:sleep sleep "$seconds" </dev/null >/dev/null 2>&1 & fi
else fail no_tool; fi
pid=$!
# Loaded machine: wait for nohup to have started the tool (5 s max), then 1 s
# so an immediate failure has time to show.
i=0
while [ "$i" -lt 50 ] && running "$pid" && ! ours "$pid"; do sleep 0.1; i=$((i + 1)); done
sleep 1
# Failure: the old inhibitor (if any) keeps running, file untouched.
ours "$pid" || fail start_failed
start=$(started "$pid")
printf '%s|%s|%s|%s\\n' "$pid" "$until" "$lid" "$start" > "$d.tmp" && mv "$d.tmp" "$d"
if [ -n "$old_pid" ] && [ "$old_pid" != "$pid" ]; then kill "$old_pid" 2>/dev/null || true; fi
echo "started=$pid"`;
const ASSERTIONS_SCRIPT = "pmset -g assertions 2>/dev/null";
function parseBattery(raw) {
  const percent = /\b(\d{1,3})%/.exec(raw);
  if (!percent) return null;
  return { percent: Math.min(100, Number(percent[1])), source: /AC Power/i.test(raw) ? "ac" : "battery" };
}
function parseAwakeStatus(raw) {
  var _a, _b, _c;
  const platform = ((_a = /^platform=(mac|linux|other)$/m.exec(raw)) == null ? void 0 : _a[1]) || "other";
  const match = /^awake=(\d+)\|(\d+)\|([01])$/m.exec(raw);
  return {
    platform,
    supported: platform === "mac" || platform === "linux" && /^inhibit=1$/m.test(raw),
    active: Boolean(match),
    until: match && Number(match[2]) ? Number(match[2]) * 1e3 : null,
    lid: (match == null ? void 0 : match[3]) === "1",
    battery: platform === "mac" ? parseBattery(raw) : null,
    eveningPast: Number((_c = (_b = /^clock=(\d{4})$/m.exec(raw)) == null ? void 0 : _b[1]) != null ? _c : 0) >= 2e3
  };
}
function parseAssertions(raw, ownPid) {
  const rows = [];
  for (const line of raw.split("\n")) {
    const m = /pid (\d+)\(([^)]+)\):.*? (\d{1,3}:\d\d:\d\d) (PreventUserIdleSystemSleep|PreventSystemSleep)\b/.exec(line);
    if (!m) continue;
    const [hours, minutes, seconds] = m[3].split(":").map(Number);
    rows.push({ name: m[2], kind: m[4], seconds: hours * 3600 + minutes * 60 + seconds, ours: Number(m[1]) === ownPid });
  }
  return rows;
}
function localExec(script, args) {
  return new Promise((resolve) => execFile("sh", ["-c", script, "sh", ...args], { timeout: 1e4, maxBuffer: 1024 * 1024 }, (err, stdout, stderr) => resolve({ code: err ? 1 : 0, stdout: Buffer.from(stdout), stderr: String(stderr || (err == null ? void 0 : err.message) || "") })));
}
async function run(machine, script, args = []) {
  const result = machine.exec ? await machine.exec(script, args, { timeoutMs: 1e4 }) : await localExec(script, args);
  if (result.code !== 0) throw new HerdrError("awake_command_failed", result.stderr.trim() || "Keep-awake command failed");
  return result.stdout.toString("utf8");
}
async function awakeStatus(machine) {
  return parseAwakeStatus(await run(machine, STATUS_SCRIPT));
}
const CONTROL_ERRORS = {
  no_tool: "Sleep control is not available on this machine",
  lid_mac_only: "Closed lid is only available on a Mac",
  evening_past: "It is already past 8 pm on this machine: pick a duration",
  not_active: "Nothing to extend: the machine is not being kept awake",
  bad_mode: "Invalid keep-awake option",
  start_failed: "Keep awake did not start; the previous state is kept"
};
function parseControl(raw) {
  var _a, _b;
  const error = (_a = /^error=(\w+)$/m.exec(raw)) == null ? void 0 : _a[1];
  if (error) return { error };
  return { started: Number((_b = /^started=(\d+)$/m.exec(raw)) == null ? void 0 : _b[1]) || null };
}
async function setAwake(machine, mode, lid) {
  var _a;
  const status = await awakeStatus(machine);
  if (!status.supported) throw new HerdrError("awake_unsupported", CONTROL_ERRORS.no_tool);
  if (mode === "extend") {
    if (!status.active || !status.until) throw new HerdrError("awake_not_active", CONTROL_ERRORS.not_active);
    lid = status.lid;
  }
  if (mode === "evening" && status.eveningPast) throw new HerdrError("awake_evening_past", CONTROL_ERRORS.evening_past);
  if (lid && status.platform !== "mac") throw new HerdrError("awake_lid", CONTROL_ERRORS.lid_mac_only);
  if (lid && ((_a = status.battery) == null ? void 0 : _a.source) !== "ac") throw new HerdrError("awake_lid", "Closed lid requires the power adapter");
  const result = parseControl(await run(machine, CONTROL_SCRIPT, [mode, lid ? "1" : "0"]));
  if ("error" in result) throw new HerdrError(`awake_${result.error}`, CONTROL_ERRORS[result.error] || "Keep-awake command failed");
  const after = await awakeStatus(machine);
  if (mode !== "off" && !after.active) throw new HerdrError("awake_start_failed", CONTROL_ERRORS.start_failed);
  return after;
}
async function sleepAssertions(machine) {
  const status = await awakeStatus(machine);
  if (status.platform !== "mac") return [];
  const raw = await run(machine, ASSERTIONS_SCRIPT);
  const pid = /^awake=(\d+)/m.exec(await run(machine, STATUS_SCRIPT));
  return parseAssertions(raw, pid ? Number(pid[1]) : void 0);
}

export { awakeStatus as a, setAwake as b, sleepAssertions as s };
//# sourceMappingURL=awake.mjs.map

import { cb as allMachines, $ as getMachine, H as HerdrError, a_ as splitId, aZ as herdrOn, p as poll, an as recentDirs, cc as joinId, a$ as getState } from '../nitro/nitro.mjs';

const opts = { trust_repository: true };
async function machineWorktrees(m) {
  const st = getState();
  const mine = st.panes.filter((p) => splitId(p.id).machine === m.key);
  const cwds = [...new Set([...mine.map((p) => p.cwd), ...(await recentDirs(m)).slice(0, 12)].filter((c) => Boolean(c && c.startsWith("/"))))];
  const repos = /* @__PURE__ */ new Set();
  const out = [];
  for (const cwd of cwds.slice(0, 30)) {
    let r;
    try {
      r = await herdrOn(m.key, "worktree.list", { cwd, ...opts }, 8e3);
    } catch {
      continue;
    }
    const src = r.source || {};
    const key = String(src.repo_key || src.repo_root || cwd);
    if (repos.has(key)) continue;
    repos.add(key);
    for (const w of r.worktrees || []) {
      if (!w.is_linked_worktree || w.is_bare) continue;
      const ws = w.open_workspace_id ? joinId(m.key, String(w.open_workspace_id)) : null;
      const panes = ws ? mine.filter((p) => p.workspace === ws) : [];
      out.push({
        machine: m.key,
        repo: String(src.repo_name || ""),
        repoRoot: String(src.repo_root || ""),
        path: String(w.path),
        branch: w.is_detached ? null : w.branch ? String(w.branch) : null,
        workspace: ws,
        agents: panes.filter((p) => p.agent).length,
        panes: panes.length,
        prunable: Boolean(w.is_prunable)
      });
    }
  }
  return out;
}
async function listWorktrees() {
  const all = [];
  for (const m of allMachines()) {
    if (m.info().baseKey) continue;
    if (!m.local && m.status !== "online") continue;
    all.push(...await machineWorktrees(m).catch(() => []));
  }
  return all.sort((a, b) => a.repo.localeCompare(b.repo) || String(a.branch).localeCompare(String(b.branch)));
}
async function removeWorktree(machine, path, force) {
  const m = getMachine(machine);
  if (!m || !m.local && m.status !== "online") throw new HerdrError("unreachable", "Machine unreachable");
  const wt = (await machineWorktrees(m)).find((w) => w.path === path);
  if (!wt) throw new HerdrError("not_found", "Worktree not found");
  let ws = wt.workspace ? splitId(wt.workspace).local : null;
  let reopened = false;
  if (!ws) {
    const o = await herdrOn(m.key, "worktree.open", { cwd: wt.repoRoot, path, focus: false, ...opts }, 2e4);
    ws = String(o.workspace.workspace_id);
    reopened = true;
  }
  try {
    await herdrOn(m.key, "worktree.remove", { workspace_id: ws, force, ...opts }, 3e4);
  } catch (e) {
    if (reopened) await herdrOn(m.key, "workspace.close", { workspace_id: ws }).catch(() => {
    });
    if (e.code === "dirty_worktree_requires_force") throw new HerdrError("dirty", "Uncommitted changes in this worktree");
    throw e;
  }
  poll();
  return { ok: true };
}

export { listWorktrees as l, removeWorktree as r };
//# sourceMappingURL=worktrees.mjs.map

(function() {
	//#region app/service-worker/networkFirst.ts
	async function networkFirst(network, cached, waitMs) {
		const answer = network.catch(() => null);
		const late = new Promise((resolve) => {
			const timer = setTimeout(resolve, waitMs);
			answer.then(() => clearTimeout(timer));
		});
		const first = await Promise.race([answer, late]);
		if (first) return first;
		return await cached().catch(() => void 0) || await answer || Response.error();
	}
	//#endregion
	//#region app/service-worker/sw.ts
	var sw = self;
	var CACHE = "wherdr-v1";
	var NETWORK_WAIT_MS = 3e3;
	var PRECACHE = ["/", ...[{"revision":"e6a852ba6e2a724d2255af526cb04083","url":"manifest.webmanifest"},{"revision":"b1a14fab8c06784649bf26c636747a86","url":"manifest-en.webmanifest"},{"revision":null,"url":"_nuxt/wherdr-symbols.C1LsPKmg.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-powerline.B_kAMxXr.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-octicons.Hl4VEx8m.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-material-4.CO_PudDR.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-material-3.8xz7iX-Y.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-material-2.C_flbBWO.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-material-1.BdvqkCqW.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-extension.Dai_ky39.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-devicons.ZMSFX1sW.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-codicons.CtEsfSAf.woff2"},{"revision":null,"url":"_nuxt/wherdr-nerd-awesome.DQ3_iAfa.woff2"},{"revision":null,"url":"_nuxt/settings.Cdb21nNw.css"},{"revision":null,"url":"_nuxt/jetbrains-mono-vietnamese-wght-normal.Bt-aOZkq.woff2"},{"revision":null,"url":"_nuxt/jetbrains-mono-latin-wght-normal.B9CIFXIH.woff2"},{"revision":null,"url":"_nuxt/jetbrains-mono-latin-ext-wght-normal.DBQx-q_a.woff2"},{"revision":null,"url":"_nuxt/jetbrains-mono-greek-wght-normal.Bw9x6K1M.woff2"},{"revision":null,"url":"_nuxt/jetbrains-mono-cyrillic-wght-normal.D73BlboJ.woff2"},{"revision":null,"url":"_nuxt/inter-vietnamese-wght-normal.CBcvBZtf.woff2"},{"revision":null,"url":"_nuxt/inter-latin-wght-normal.Dx4kXJAl.woff2"},{"revision":null,"url":"_nuxt/inter-latin-ext-wght-normal.DO1Apj_S.woff2"},{"revision":null,"url":"_nuxt/inter-greek-wght-normal.CkhJZR-_.woff2"},{"revision":null,"url":"_nuxt/inter-greek-ext-wght-normal.DlzME5K_.woff2"},{"revision":null,"url":"_nuxt/inter-cyrillic-wght-normal.DqGufNeO.woff2"},{"revision":null,"url":"_nuxt/inter-cyrillic-ext-wght-normal.BOeWTOD4.woff2"},{"revision":null,"url":"_nuxt/hePW80VL.js"},{"revision":null,"url":"_nuxt/error-500.Bwd7zAaE.css"},{"revision":null,"url":"_nuxt/error-404.Bb87HomL.css"},{"revision":null,"url":"_nuxt/entry.CKoXcwRa.css"},{"revision":null,"url":"_nuxt/board.CEEcFc6M.css"},{"revision":null,"url":"_nuxt/archivo-vietnamese-wght-normal.XAtsl5Q_.woff2"},{"revision":null,"url":"_nuxt/archivo-latin-wght-normal.E0tuGl4L.woff2"},{"revision":null,"url":"_nuxt/archivo-latin-ext-wght-normal.C4zznr8T.woff2"},{"revision":null,"url":"_nuxt/R0Y4VoeX.js"},{"revision":null,"url":"_nuxt/NIF0VwHk.js"},{"revision":null,"url":"_nuxt/FaNto0ga.js"},{"revision":null,"url":"_nuxt/DyfFwwGq.js"},{"revision":null,"url":"_nuxt/DrKKeFFE.js"},{"revision":null,"url":"_nuxt/DmkWvmnE.js"},{"revision":null,"url":"_nuxt/DZGKxROq.js"},{"revision":null,"url":"_nuxt/DFmgQVme.js"},{"revision":null,"url":"_nuxt/DFGEl0v2.js"},{"revision":null,"url":"_nuxt/CuUQ4mEf.js"},{"revision":null,"url":"_nuxt/CXJnLmWv.js"},{"revision":null,"url":"_nuxt/CDWjMk9C.js"},{"revision":null,"url":"_nuxt/C3Bkn4ac.js"},{"revision":null,"url":"_nuxt/C25ROUa9.js"},{"revision":null,"url":"_nuxt/BtH82ZuZ.js"},{"revision":null,"url":"_nuxt/Bpoxvzh6.js"},{"revision":null,"url":"_nuxt/BhgehRdJ.js"},{"revision":null,"url":"_nuxt/Bd17z0YL.js"},{"revision":null,"url":"_nuxt/BYZVrreW.js"},{"revision":null,"url":"_nuxt/BHenDMeH.js"},{"revision":null,"url":"_nuxt/BETID3_E.js"},{"revision":null,"url":"_nuxt/BDNMzG2s.js"},{"revision":null,"url":"_nuxt/AgentView.DzFWBd2A.css"},{"revision":"ff114ee76a723280d3f2dcdb163f5595","url":"_nuxt/builds/latest.json"},{"revision":null,"url":"_nuxt/builds/meta/a6ce818a-c3b3-41ab-82c3-dc2f01687a98.json"}].map((e) => "/" + (typeof e === "string" ? e : e.url).replace(/^\//, ""))];
	sw.addEventListener("install", (e) => {
		e.waitUntil((async () => {
			const c = await caches.open(CACHE);
			await Promise.all(PRECACHE.map((u) => c.add(new Request(u, { cache: "no-cache" })).catch(() => {})));
		})());
	});
	sw.addEventListener("message", (e) => {
		if (e.data && e.data.type === "skip-waiting") sw.skipWaiting();
	});
	sw.addEventListener("activate", (e) => {
		e.waitUntil((async () => {
			for (const k of await caches.keys()) if (k !== CACHE) await caches.delete(k);
			await sw.clients.claim();
		})());
	});
	async function keep(req, res) {
		if (!res.ok) return;
		const copy = res.clone();
		await (await caches.open(CACHE)).put(req, copy);
	}
	sw.addEventListener("fetch", (e) => {
		const req = e.request;
		const url = new URL(req.url);
		if (req.method !== "GET" || url.origin !== sw.location.origin || url.pathname.startsWith("/api/") || url.pathname.startsWith("/ws/") || url.pathname.startsWith("/uploads/")) return;
		if (url.pathname.startsWith("/_nuxt/") && !url.pathname.startsWith("/_nuxt/builds/")) {
			const cached = caches.match(req).catch(() => void 0);
			const fresh = cached.then((hit) => hit ? void 0 : fetch(req));
			e.waitUntil(fresh.then((res) => res && keep(req, res)).catch(() => {}));
			e.respondWith(cached.then(async (hit) => hit || await fresh));
			return;
		}
		const network = fetch(req, { cache: "no-cache" });
		e.waitUntil(network.then((res) => keep(req, res)).catch(() => {}));
		const fromCache = async () => await caches.match(req) || (req.mode === "navigate" ? caches.match("/") : void 0);
		e.respondWith(networkFirst(network, fromCache, NETWORK_WAIT_MS));
	});
	sw.addEventListener("push", (e) => {
		let d = {};
		try {
			d = e.data ? e.data.json() : {};
		} catch {
			d = { body: e.data ? e.data.text() : "" };
		}
		e.waitUntil((async () => {
			await sw.registration.showNotification(d.title || "wherdr", {
				body: d.body || "",
				tag: d.tag || "herdr",
				renotify: true,
				icon: "/icons/icon-192.png?v=5",
				badge: "/icons/icon-192.png?v=5",
				data: { url: d.url || "/" }
			});
			try {
				if (typeof d.badge === "number" && sw.navigator.setAppBadge) await sw.navigator.setAppBadge(d.badge);
			} catch {}
		})());
	});
	sw.addEventListener("notificationclick", (e) => {
		e.notification.close();
		e.waitUntil((async () => {
			let target = "/";
			try {
				const u = new URL(e.notification.data && e.notification.data.url || "/", sw.location.origin);
				if (u.origin === sw.location.origin) target = u.pathname + u.search + u.hash;
			} catch {}
			const wins = await sw.clients.matchAll({
				type: "window",
				includeUncontrolled: true
			});
			for (const c of wins) if (c.url.startsWith(sw.location.origin)) {
				c.postMessage({
					type: "navigate",
					url: target
				});
				return c.focus();
			}
			return sw.clients.openWindow(target);
		})());
	});
	//#endregion
})();
